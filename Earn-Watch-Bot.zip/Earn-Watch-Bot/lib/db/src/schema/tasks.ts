import { pgTable, text, serial, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const taskDefinitionsTable = pgTable("task_definitions", {
  id: serial("id").primaryKey(),
  taskType: text("task_type").notNull(), // watch_ad, visit_link, daily_login, signup_bonus
  title: text("title").notNull(),
  description: text("description").notNull(),
  buttonText: text("button_text").notNull().default("Start"),
  rewardCoins: integer("reward_coins").notNull(),
  adUrl: text("ad_url"),
  linkUrl: text("link_url"),
  taskOrder: integer("task_order").notNull().default(0),
  timerSeconds: integer("timer_seconds").notNull().default(15),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const userTaskCompletionsTable = pgTable("user_task_completions", {
  id: serial("id").primaryKey(),
  telegramId: text("telegram_id").notNull(),
  taskDefinitionId: integer("task_definition_id").notNull(),
  completedDate: text("completed_date").notNull(), // YYYY-MM-DD
  completedAt: timestamp("completed_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTaskDefinitionSchema = createInsertSchema(taskDefinitionsTable).omit({ id: true, createdAt: true });
export type InsertTaskDefinition = z.infer<typeof insertTaskDefinitionSchema>;
export type TaskDefinition = typeof taskDefinitionsTable.$inferSelect;

export const insertUserTaskCompletionSchema = createInsertSchema(userTaskCompletionsTable).omit({ id: true, completedAt: true });
export type InsertUserTaskCompletion = z.infer<typeof insertUserTaskCompletionSchema>;
export type UserTaskCompletion = typeof userTaskCompletionsTable.$inferSelect;
