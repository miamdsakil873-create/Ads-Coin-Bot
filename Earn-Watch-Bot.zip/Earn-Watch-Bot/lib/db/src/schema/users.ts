import { pgTable, text, serial, timestamp, integer, boolean, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  telegramId: text("telegram_id").notNull().unique(),
  username: text("username").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name"),
  email: text("email"),
  passwordHash: text("password_hash"),
  balance: numeric("balance", { precision: 12, scale: 4 }).notNull().default("0"),
  pendingBalance: numeric("pending_balance", { precision: 12, scale: 4 }).notNull().default("0"),
  withdrawableBalance: numeric("withdrawable_balance", { precision: 12, scale: 4 }).notNull().default("0"),
  totalEarned: numeric("total_earned", { precision: 12, scale: 4 }).notNull().default("0"),
  referralCode: text("referral_code").notNull().unique(),
  referredBy: text("referred_by"),
  level: integer("level").notNull().default(1),
  isAdmin: boolean("is_admin").notNull().default(false),
  isBanned: boolean("is_banned").notNull().default(false),
  streakDays: integer("streak_days").notNull().default(0),
  lastLoginDate: text("last_login_date"),
  spinAvailable: boolean("spin_available").notNull().default(false),
  scratchAvailable: boolean("scratch_available").notNull().default(false),
  ipAddress: text("ip_address"),
  deviceId: text("device_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
