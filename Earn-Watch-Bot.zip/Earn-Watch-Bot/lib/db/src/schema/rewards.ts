import { pgTable, text, serial, timestamp, integer, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const rewardLogsTable = pgTable("reward_logs", {
  id: serial("id").primaryKey(),
  telegramId: text("telegram_id").notNull(),
  rewardType: text("reward_type").notNull(), // spin, scratch, task, referral_bonus
  prize: text("prize").notNull(),
  coinsEarned: integer("coins_earned").notNull(),
  rewardDate: text("reward_date").notNull(), // YYYY-MM-DD for daily limits
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertRewardLogSchema = createInsertSchema(rewardLogsTable).omit({ id: true, createdAt: true });
export type InsertRewardLog = z.infer<typeof insertRewardLogSchema>;
export type RewardLog = typeof rewardLogsTable.$inferSelect;
