import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth-context";
import {
  LayoutDashboard, Users, ListChecks, Wallet, Megaphone, Radio, Settings, LogOut, Shield
} from "lucide-react";
import { useAdminGetWithdrawals } from "@workspace/api-client-react";

const navItems = [
  { href: "/", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/users", icon: Users, label: "Users" },
  { href: "/tasks", icon: ListChecks, label: "Tasks" },
  { href: "/withdrawals", icon: Wallet, label: "Withdrawals", badge: true },
  { href: "/announcements", icon: Megaphone, label: "Announcements" },
  { href: "/broadcast", icon: Radio, label: "Broadcast" },
  { href: "/settings", icon: Settings, label: "Settings" },
];

export function Sidebar() {
  const [location] = useLocation();
  const { logout, username } = useAuth();
  const { data: withdrawals } = useAdminGetWithdrawals({ status: "pending" });
  const pendingCount = withdrawals?.length ?? 0;

  return (
    <aside className="w-60 min-h-screen bg-sidebar flex flex-col border-r border-sidebar-border shrink-0">
      <div className="flex items-center gap-2.5 px-5 py-5 border-b border-sidebar-border">
        <div className="w-8 h-8 bg-sidebar-primary rounded-lg flex items-center justify-center">
          <Shield className="w-4 h-4 text-sidebar-primary-foreground" />
        </div>
        <div>
          <div className="text-sm font-bold text-sidebar-foreground leading-tight">Admin Panel</div>
          <div className="text-xs text-sidebar-foreground/50">Watch Ads &amp; Earn</div>
        </div>
      </div>

      <nav className="flex-1 p-3 space-y-0.5">
        {navItems.map((item) => {
          const active = location === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                active
                  ? "bg-sidebar-accent text-white"
                  : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
              }`}
            >
              <item.icon className="w-4 h-4 shrink-0" />
              <span className="flex-1">{item.label}</span>
              {item.badge && pendingCount > 0 && (
                <span className="bg-red-500 text-white text-xs font-bold rounded-full px-1.5 py-0.5 leading-none min-w-[18px] text-center">
                  {pendingCount}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      <div className="p-3 border-t border-sidebar-border">
        <div className="flex items-center gap-2 px-3 py-2 mb-1">
          <div className="w-7 h-7 bg-sidebar-accent rounded-full flex items-center justify-center text-xs font-bold text-sidebar-foreground">
            {username?.[0]?.toUpperCase() ?? "A"}
          </div>
          <span className="text-sm text-sidebar-foreground/80 font-medium">{username ?? "admin"}</span>
        </div>
        <button
          onClick={logout}
          className="flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium text-sidebar-foreground/60 hover:text-red-400 hover:bg-sidebar-accent/50 w-full transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Logout
        </button>
      </div>
    </aside>
  );
}
