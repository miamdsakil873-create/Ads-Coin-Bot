import { type ReactNode } from "react";
import { Sidebar } from "./sidebar";

interface LayoutProps {
  title: string;
  children: ReactNode;
}

export function Layout({ title, children }: LayoutProps) {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="border-b bg-white px-6 py-4">
          <h1 className="text-xl font-bold text-gray-900">{title}</h1>
        </div>
        <div className="p-6">{children}</div>
      </main>
    </div>
  );
}
