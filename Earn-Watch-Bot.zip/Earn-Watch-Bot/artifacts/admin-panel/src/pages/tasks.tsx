import { useState } from "react";
import {
  useAdminGetTasks, useAdminCreateTask, useAdminUpdateTask, useAdminDeleteTask,
  getAdminGetTasksQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/layout";
import { Plus, Pencil, Trash2 } from "lucide-react";

const TASK_TYPES = ["watch_ad", "visit_link", "daily_login", "signup_bonus"] as const;

const emptyForm = {
  taskType: "watch_ad" as string,
  title: "",
  description: "",
  buttonText: "Watch Ad",
  rewardCoins: 5,
  adUrl: "",
  linkUrl: "",
  taskOrder: 0,
  timerSeconds: 15,
  isActive: true,
};

export default function TasksAdmin() {
  const queryClient = useQueryClient();
  const { data: tasks, isLoading } = useAdminGetTasks();
  const createMutation = useAdminCreateTask();
  const updateMutation = useAdminUpdateTask();
  const deleteMutation = useAdminDeleteTask();

  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  const refresh = () => queryClient.invalidateQueries({ queryKey: getAdminGetTasksQueryKey() });

  const openCreate = () => {
    setEditId(null);
    setForm(emptyForm);
    setShowForm(true);
  };

  const openEdit = (task: any) => {
    setEditId(task.id);
    setForm({
      taskType: task.taskType,
      title: task.title,
      description: task.description,
      buttonText: task.buttonText,
      rewardCoins: task.rewardCoins,
      adUrl: task.adUrl ?? "",
      linkUrl: task.linkUrl ?? "",
      taskOrder: task.taskOrder,
      timerSeconds: task.timerSeconds,
      isActive: task.isActive,
    });
    setShowForm(true);
  };

  const handleSave = () => {
    const payload = {
      taskType: form.taskType as any,
      title: form.title,
      description: form.description,
      buttonText: form.buttonText,
      rewardCoins: Number(form.rewardCoins),
      adUrl: form.adUrl || null,
      linkUrl: form.linkUrl || null,
      taskOrder: Number(form.taskOrder),
      timerSeconds: Number(form.timerSeconds),
      isActive: form.isActive,
    };

    if (editId !== null) {
      updateMutation.mutate(
        { params: { id: editId }, data: payload },
        { onSuccess: () => { refresh(); setShowForm(false); } }
      );
    } else {
      createMutation.mutate(
        { data: payload },
        { onSuccess: () => { refresh(); setShowForm(false); } }
      );
    }
  };

  const handleDelete = (id: number) => {
    deleteMutation.mutate(
      { params: { id } },
      { onSuccess: () => { refresh(); setDeleteConfirm(null); } }
    );
  };

  const f = (k: keyof typeof form, v: any) => setForm((p) => ({ ...p, [k]: v }));

  return (
    <Layout title="Task Management">
      <div className="space-y-4">
        <div className="flex justify-end">
          <button
            onClick={openCreate}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700"
          >
            <Plus className="w-4 h-4" /> New Task
          </button>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50">
                <th className="text-left px-4 py-3 font-semibold text-gray-600">Task</th>
                <th className="text-left px-4 py-3 font-semibold text-gray-600">Type</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">Reward</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">Timer</th>
                <th className="text-center px-4 py-3 font-semibold text-gray-600">Status</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 6 }).map((_, j) => (
                      <td key={j} className="px-4 py-3"><div className="h-4 bg-gray-100 rounded animate-pulse" /></td>
                    ))}
                  </tr>
                ))
              ) : tasks?.map((task) => (
                <tr key={task.id} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3">
                    <div className="font-medium text-gray-900">{task.title}</div>
                    <div className="text-xs text-gray-400 line-clamp-1">{task.description}</div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-700">
                      {task.taskType}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right font-semibold text-green-600">+{task.rewardCoins}</td>
                  <td className="px-4 py-3 text-right text-gray-500">{task.timerSeconds}s</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                      task.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"
                    }`}>
                      {task.isActive ? "Active" : "Inactive"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => openEdit(task)}
                        className="p-1.5 rounded-md hover:bg-gray-100 text-gray-400 hover:text-gray-700"
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setDeleteConfirm(task.id)}
                        className="p-1.5 rounded-md hover:bg-red-50 text-red-400 hover:text-red-600"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
            <h3 className="text-lg font-bold mb-4">{editId ? "Edit Task" : "Create Task"}</h3>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Task Type</label>
                  <select
                    value={form.taskType}
                    onChange={(e) => f("taskType", e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {TASK_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Order</label>
                  <input type="number" value={form.taskOrder} onChange={(e) => f("taskOrder", e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Title</label>
                <input type="text" value={form.title} onChange={(e) => f("title", e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Description</label>
                <textarea value={form.description} onChange={(e) => f("description", e.target.value)} rows={2}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Button Text</label>
                  <input type="text" value={form.buttonText} onChange={(e) => f("buttonText", e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Reward Coins</label>
                  <input type="number" value={form.rewardCoins} onChange={(e) => f("rewardCoins", e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Timer (secs)</label>
                  <input type="number" value={form.timerSeconds} onChange={(e) => f("timerSeconds", e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
              </div>
              {(form.taskType === "watch_ad") && (
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Ad URL (optional)</label>
                  <input type="url" value={form.adUrl} onChange={(e) => f("adUrl", e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
              )}
              {(form.taskType === "visit_link" || form.taskType === "signup_bonus") && (
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Link URL</label>
                  <input type="url" value={form.linkUrl} onChange={(e) => f("linkUrl", e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
              )}
              <div className="flex items-center gap-2">
                <input type="checkbox" id="isActive" checked={form.isActive} onChange={(e) => f("isActive", e.target.checked)}
                  className="rounded border-gray-300" />
                <label htmlFor="isActive" className="text-sm font-medium text-gray-700">Active</label>
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setShowForm(false)}
                className="flex-1 border border-gray-300 rounded-lg py-2 text-sm font-medium hover:bg-gray-50">
                Cancel
              </button>
              <button onClick={handleSave}
                disabled={createMutation.isPending || updateMutation.isPending}
                className="flex-1 bg-blue-600 text-white rounded-lg py-2 text-sm font-medium hover:bg-blue-700 disabled:opacity-50">
                {createMutation.isPending || updateMutation.isPending ? "Saving..." : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}

      {deleteConfirm !== null && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-sm shadow-2xl">
            <h3 className="text-lg font-bold mb-2">Delete Task?</h3>
            <p className="text-sm text-gray-500 mb-5">This action cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)}
                className="flex-1 border border-gray-300 rounded-lg py-2 text-sm font-medium hover:bg-gray-50">
                Cancel
              </button>
              <button onClick={() => handleDelete(deleteConfirm!)}
                disabled={deleteMutation.isPending}
                className="flex-1 bg-red-600 text-white rounded-lg py-2 text-sm font-medium hover:bg-red-700 disabled:opacity-50">
                {deleteMutation.isPending ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}
