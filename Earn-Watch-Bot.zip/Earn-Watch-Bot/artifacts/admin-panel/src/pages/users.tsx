import { useState } from "react";
import { useAdminGetUsers, useAdminUpdateUser, getAdminGetUsersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/layout";
import { Search, Ban, CheckCircle, Edit2 } from "lucide-react";

export default function Users() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [editUser, setEditUser] = useState<any>(null);
  const [editBalance, setEditBalance] = useState("");
  const [editWithdrawable, setEditWithdrawable] = useState("");

  const { data, isLoading } = useAdminGetUsers({ page, limit: 20, search: search || undefined });
  const updateMutation = useAdminUpdateUser();

  const handleBanToggle = (user: any) => {
    updateMutation.mutate(
      { params: { id: user.id }, data: { isBanned: !user.isBanned } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getAdminGetUsersQueryKey() });
        },
      }
    );
  };

  const handleEditSave = () => {
    if (!editUser) return;
    updateMutation.mutate(
      {
        params: { id: editUser.id },
        data: {
          balance: parseFloat(editBalance),
          withdrawableBalance: parseFloat(editWithdrawable),
        },
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getAdminGetUsersQueryKey() });
          setEditUser(null);
        },
      }
    );
  };

  const openEdit = (user: any) => {
    setEditUser(user);
    setEditBalance(String(user.balance));
    setEditWithdrawable(String(user.withdrawableBalance));
  };

  return (
    <Layout title="User Management">
      <div className="space-y-4">
        <div className="flex gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="search"
              placeholder="Search by username or Telegram ID..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              className="w-full border border-gray-300 rounded-lg pl-9 pr-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50">
                <th className="text-left px-4 py-3 font-semibold text-gray-600">User</th>
                <th className="text-left px-4 py-3 font-semibold text-gray-600">Telegram ID</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">Balance</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">Earned</th>
                <th className="text-center px-4 py-3 font-semibold text-gray-600">Status</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {isLoading ? (
                Array.from({ length: 10 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 6 }).map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="h-4 bg-gray-100 rounded animate-pulse" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : data?.users.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3">
                    <div>
                      <div className="font-medium text-gray-900">{user.firstName} {user.lastName}</div>
                      <div className="text-xs text-gray-400">@{user.username}</div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-gray-600 font-mono text-xs">{user.telegramId}</td>
                  <td className="px-4 py-3 text-right font-semibold">{Number(user.balance).toFixed(2)}</td>
                  <td className="px-4 py-3 text-right text-gray-600">{Number(user.totalEarned).toFixed(2)}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                      user.isBanned ? "bg-red-100 text-red-700" : "bg-green-100 text-green-700"
                    }`}>
                      {user.isBanned ? "Banned" : "Active"}
                    </span>
                    {user.isAdmin && (
                      <span className="ml-1 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-700">Admin</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => openEdit(user)}
                        className="p-1.5 rounded-md hover:bg-gray-100 text-gray-400 hover:text-gray-700 transition-colors"
                        title="Edit balance"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleBanToggle(user)}
                        disabled={updateMutation.isPending}
                        className={`p-1.5 rounded-md transition-colors ${
                          user.isBanned
                            ? "hover:bg-green-50 text-green-600 hover:text-green-700"
                            : "hover:bg-red-50 text-red-500 hover:text-red-600"
                        }`}
                        title={user.isBanned ? "Unban" : "Ban"}
                      >
                        {user.isBanned ? <CheckCircle className="w-3.5 h-3.5" /> : <Ban className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {data && (
          <div className="flex items-center justify-between text-sm text-gray-500">
            <span>{data.total} total users</span>
            <div className="flex gap-2">
              <button
                disabled={page === 1}
                onClick={() => setPage(p => p - 1)}
                className="px-3 py-1.5 border border-gray-300 rounded-lg disabled:opacity-40 hover:bg-gray-50"
              >
                Previous
              </button>
              <span className="px-3 py-1.5">Page {page}</span>
              <button
                disabled={page * 20 >= data.total}
                onClick={() => setPage(p => p + 1)}
                className="px-3 py-1.5 border border-gray-300 rounded-lg disabled:opacity-40 hover:bg-gray-50"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>

      {editUser && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-sm shadow-2xl">
            <h3 className="text-lg font-bold mb-4">Edit Balance — {editUser.firstName}</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Balance (Coins)</label>
                <input
                  type="number"
                  value={editBalance}
                  onChange={(e) => setEditBalance(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Withdrawable Balance</label>
                <input
                  type="number"
                  value={editWithdrawable}
                  onChange={(e) => setEditWithdrawable(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button
                onClick={() => setEditUser(null)}
                className="flex-1 border border-gray-300 rounded-lg py-2 text-sm font-medium hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleEditSave}
                disabled={updateMutation.isPending}
                className="flex-1 bg-blue-600 text-white rounded-lg py-2 text-sm font-medium hover:bg-blue-700 disabled:opacity-50"
              >
                {updateMutation.isPending ? "Saving..." : "Save Changes"}
              </button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}
