import { useState } from "react";
import { useAdminBroadcast } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Radio, CheckCircle } from "lucide-react";

export default function Broadcast() {
  const mutation = useAdminBroadcast();
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [targetId, setTargetId] = useState("");
  const [result, setResult] = useState<{ success: boolean; recipientCount: number; message: string } | null>(null);

  const handleSend = () => {
    setResult(null);
    mutation.mutate(
      { data: { title, message, targetTelegramId: targetId || undefined } },
      {
        onSuccess: (res) => {
          setResult(res as any);
          setTitle(""); setMessage(""); setTargetId("");
        },
        onError: () => {
          setResult({ success: false, recipientCount: 0, message: "Failed to send broadcast. Please try again." });
        }
      }
    );
  };

  return (
    <Layout title="Broadcast Message">
      <div className="max-w-2xl space-y-4">
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Radio className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h2 className="font-semibold text-gray-900">Send Broadcast</h2>
              <p className="text-sm text-gray-500">Send a message to all users or a specific user</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Target User (optional)
              </label>
              <input
                type="text"
                value={targetId}
                onChange={(e) => setTargetId(e.target.value)}
                placeholder="Telegram ID — leave empty to send to all users"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Announcement title..."
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Type your message here..."
                rows={5}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
              />
            </div>

            {result && (
              <div className={`flex items-start gap-3 p-4 rounded-lg ${
                result.success ? "bg-green-50 border border-green-200" : "bg-red-50 border border-red-200"
              }`}>
                {result.success && <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 shrink-0" />}
                <div>
                  <p className={`text-sm font-medium ${result.success ? "text-green-800" : "text-red-800"}`}>
                    {result.message}
                  </p>
                  {result.success && (
                    <p className="text-xs text-green-600 mt-0.5">{result.recipientCount} recipient(s)</p>
                  )}
                </div>
              </div>
            )}

            <button
              onClick={handleSend}
              disabled={mutation.isPending || !title.trim() || !message.trim()}
              className="w-full bg-blue-600 text-white py-2.5 rounded-lg text-sm font-semibold hover:bg-blue-700 disabled:opacity-50 transition-colors"
            >
              {mutation.isPending ? "Sending..." : targetId ? "Send to User" : "Broadcast to All Users"}
            </button>
          </div>
        </div>

        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
          <p className="text-sm text-amber-800 font-medium mb-1">Note on Broadcast</p>
          <p className="text-sm text-amber-700">
            Broadcasting will post an announcement visible to all active users in their dashboard.
            Messages sent to a specific Telegram ID are logged but not yet delivered via bot.
          </p>
        </div>
      </div>
    </Layout>
  );
}
