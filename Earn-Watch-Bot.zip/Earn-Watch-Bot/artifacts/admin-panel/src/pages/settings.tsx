import { useState, useEffect } from "react";
import {
  useAdminGetSettings, useAdminUpdateSettings, getAdminGetSettingsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/layout";
import { Save, CheckCircle } from "lucide-react";

export default function Settings() {
  const queryClient = useQueryClient();
  const { data: settings, isLoading } = useAdminGetSettings();
  const updateMutation = useAdminUpdateSettings();

  const [form, setForm] = useState({
    siteName: "",
    dailyAdLimit: 10,
    rewardPerAd: 5,
    minWithdrawal: 500,
    referralLevel1Bonus: 50,
    referralLevel2Bonus: 25,
    referralLevel3Bonus: 10,
    currency: "BDT",
    botUsername: "",
  });
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (settings) {
      setForm({
        siteName: settings.siteName ?? "",
        dailyAdLimit: settings.dailyAdLimit ?? 10,
        rewardPerAd: settings.rewardPerAd ?? 5,
        minWithdrawal: settings.minWithdrawal ?? 500,
        referralLevel1Bonus: settings.referralLevel1Bonus ?? 50,
        referralLevel2Bonus: settings.referralLevel2Bonus ?? 25,
        referralLevel3Bonus: settings.referralLevel3Bonus ?? 10,
        currency: settings.currency ?? "BDT",
        botUsername: settings.botUsername ?? "",
      });
    }
  }, [settings]);

  const f = (k: keyof typeof form, v: any) => setForm((p) => ({ ...p, [k]: v }));

  const handleSave = () => {
    setSaved(false);
    updateMutation.mutate(
      { data: form as any },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getAdminGetSettingsQueryKey() });
          setSaved(true);
          setTimeout(() => setSaved(false), 3000);
        }
      }
    );
  };

  if (isLoading) {
    return (
      <Layout title="Platform Settings">
        <div className="max-w-2xl space-y-4 animate-pulse">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-10 bg-gray-100 rounded-lg" />
          ))}
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="Platform Settings">
      <div className="max-w-2xl space-y-6">
        <div className="bg-white rounded-xl border border-gray-200 p-6 space-y-5">
          <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">General</h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Site Name</label>
              <input type="text" value={form.siteName} onChange={(e) => f("siteName", e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Bot Username</label>
              <input type="text" value={form.botUsername} onChange={(e) => f("botUsername", e.target.value)}
                placeholder="@YourBot"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Currency</label>
              <select value={form.currency} onChange={(e) => f("currency", e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="BDT">BDT</option>
                <option value="USD">USD</option>
                <option value="USDT">USDT</option>
              </select>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6 space-y-5">
          <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">Rewards & Limits</h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Daily Ad Limit</label>
              <input type="number" value={form.dailyAdLimit} onChange={(e) => f("dailyAdLimit", Number(e.target.value))}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Reward per Ad (coins)</label>
              <input type="number" value={form.rewardPerAd} onChange={(e) => f("rewardPerAd", Number(e.target.value))}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Minimum Withdrawal (coins)</label>
              <input type="number" value={form.minWithdrawal} onChange={(e) => f("minWithdrawal", Number(e.target.value))}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-6 space-y-5">
          <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">Referral Bonuses</h2>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Level 1 Bonus</label>
              <input type="number" value={form.referralLevel1Bonus} onChange={(e) => f("referralLevel1Bonus", Number(e.target.value))}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Level 2 Bonus</label>
              <input type="number" value={form.referralLevel2Bonus} onChange={(e) => f("referralLevel2Bonus", Number(e.target.value))}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Level 3 Bonus</label>
              <input type="number" value={form.referralLevel3Bonus} onChange={(e) => f("referralLevel3Bonus", Number(e.target.value))}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={handleSave}
            disabled={updateMutation.isPending}
            className="flex items-center gap-2 bg-blue-600 text-white px-6 py-2.5 rounded-lg text-sm font-semibold hover:bg-blue-700 disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            {updateMutation.isPending ? "Saving..." : "Save Settings"}
          </button>
          {saved && (
            <div className="flex items-center gap-1.5 text-green-600 text-sm font-medium">
              <CheckCircle className="w-4 h-4" /> Settings saved
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
