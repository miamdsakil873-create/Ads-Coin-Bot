import { useAdminGetStats } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { Users, CheckSquare, Wallet, TrendingUp, UserX, Activity } from "lucide-react";

function StatCard({ title, value, icon: Icon, color }: { title: string; value: string | number; icon: any; color: string }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm font-medium text-gray-500">{title}</span>
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${color}`}>
          <Icon className="w-4.5 h-4.5 text-white" />
        </div>
      </div>
      <div className="text-2xl font-bold text-gray-900">{value}</div>
    </div>
  );
}

export default function Dashboard() {
  const { data: stats, isLoading } = useAdminGetStats();

  return (
    <Layout title="Dashboard">
      <div className="space-y-6">
        {isLoading ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="bg-white rounded-xl border border-gray-200 p-5 animate-pulse">
                <div className="h-4 bg-gray-100 rounded mb-3 w-2/3" />
                <div className="h-7 bg-gray-100 rounded w-1/2" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard title="Total Users" value={stats?.totalUsers ?? 0} icon={Users} color="bg-blue-500" />
            <StatCard title="Active Today" value={stats?.activeUsersToday ?? 0} icon={Activity} color="bg-green-500" />
            <StatCard title="Tasks Completed" value={stats?.totalTasksCompleted ?? 0} icon={CheckSquare} color="bg-purple-500" />
            <StatCard title="Coins Distributed" value={stats?.totalCoinsDistributed?.toFixed(0) ?? 0} icon={TrendingUp} color="bg-yellow-500" />
            <StatCard title="Pending Withdrawals" value={stats?.pendingWithdrawals ?? 0} icon={Wallet} color="bg-orange-500" />
            <StatCard title="Total Withdrawn" value={`${stats?.totalWithdrawn?.toFixed(0) ?? 0}`} icon={Wallet} color="bg-teal-500" />
            <StatCard title="Banned Users" value={stats?.bannedUsers ?? 0} icon={UserX} color="bg-red-500" />
            <StatCard title="New Today" value={stats?.newUsersToday ?? 0} icon={Users} color="bg-indigo-500" />
          </div>
        )}

        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h2 className="text-base font-semibold text-gray-900 mb-1">Platform Overview</h2>
          <p className="text-sm text-gray-500">
            Monitor your platform health. Approve pending withdrawals, manage users, and keep tasks updated to maximize engagement.
          </p>
          {stats && (
            <div className="mt-4 flex flex-wrap gap-3">
              <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-700">
                {stats.pendingWithdrawals} pending withdrawals
              </span>
              <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">
                {stats.activeUsersToday} active today
              </span>
              <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700">
                {stats.bannedUsers} banned users
              </span>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
