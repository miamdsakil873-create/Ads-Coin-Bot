import { useState } from "react";
import {
  useAdminGetWithdrawals, useAdminUpdateWithdrawalStatus,
  getAdminGetWithdrawalsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Layout } from "@/components/layout";
import { CheckCircle, XCircle } from "lucide-react";

type StatusFilter = "all" | "pending" | "approved" | "rejected";

export default function Withdrawals() {
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [actionModal, setActionModal] = useState<{ id: number; action: "approved" | "rejected" } | null>(null);
  const [note, setNote] = useState("");

  const { data: withdrawals, isLoading } = useAdminGetWithdrawals(
    statusFilter === "all" ? {} : { status: statusFilter }
  );
  const updateMutation = useAdminUpdateWithdrawalStatus();

  const handleAction = () => {
    if (!actionModal) return;
    updateMutation.mutate(
      { params: { id: actionModal.id }, data: { status: actionModal.action, note: note || undefined } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getAdminGetWithdrawalsQueryKey() });
          setActionModal(null);
          setNote("");
        },
      }
    );
  };

  const tabs: StatusFilter[] = ["all", "pending", "approved", "rejected"];

  return (
    <Layout title="Withdrawal Requests">
      <div className="space-y-4">
        <div className="flex gap-1 bg-gray-100 p-1 rounded-lg w-fit">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setStatusFilter(tab)}
              className={`px-4 py-1.5 rounded-md text-sm font-medium capitalize transition-colors ${
                statusFilter === tab
                  ? "bg-white text-gray-900 shadow-sm"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100 bg-gray-50">
                <th className="text-left px-4 py-3 font-semibold text-gray-600">User</th>
                <th className="text-left px-4 py-3 font-semibold text-gray-600">Method</th>
                <th className="text-left px-4 py-3 font-semibold text-gray-600">Account</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">Amount</th>
                <th className="text-center px-4 py-3 font-semibold text-gray-600">Status</th>
                <th className="text-left px-4 py-3 font-semibold text-gray-600">Date</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {isLoading ? (
                Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 7 }).map((_, j) => (
                      <td key={j} className="px-4 py-3"><div className="h-4 bg-gray-100 rounded animate-pulse" /></td>
                    ))}
                  </tr>
                ))
              ) : withdrawals?.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-10 text-gray-400">No withdrawals found</td>
                </tr>
              ) : withdrawals?.map((w) => (
                <tr key={w.id} className="hover:bg-gray-50/50">
                  <td className="px-4 py-3 font-mono text-xs text-gray-600">{w.telegramId}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium uppercase ${
                      w.method === "bkash" ? "bg-pink-100 text-pink-700" :
                      w.method === "nagad" ? "bg-orange-100 text-orange-700" :
                      "bg-purple-100 text-purple-700"
                    }`}>
                      {w.method}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-600 font-mono">{w.accountNumber}</td>
                  <td className="px-4 py-3 text-right font-semibold">{Number(w.amount).toFixed(2)}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                      w.status === "approved" ? "bg-green-100 text-green-700" :
                      w.status === "rejected" ? "bg-red-100 text-red-700" :
                      "bg-yellow-100 text-yellow-700"
                    }`}>
                      {w.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-400">
                    {new Date(w.createdAt).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-3 text-right">
                    {w.status === "pending" && (
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => { setActionModal({ id: w.id, action: "approved" }); setNote(""); }}
                          className="p-1.5 rounded-md hover:bg-green-50 text-green-600 hover:text-green-700"
                          title="Approve"
                        >
                          <CheckCircle className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => { setActionModal({ id: w.id, action: "rejected" }); setNote(""); }}
                          className="p-1.5 rounded-md hover:bg-red-50 text-red-500 hover:text-red-600"
                          title="Reject"
                        >
                          <XCircle className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                    {w.note && (
                      <span className="text-xs text-gray-400 italic">{w.note}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {actionModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-sm shadow-2xl">
            <h3 className="text-lg font-bold mb-2">
              {actionModal.action === "approved" ? "Approve Withdrawal" : "Reject Withdrawal"}
            </h3>
            <p className="text-sm text-gray-500 mb-4">Add an optional note for the user.</p>
            <textarea
              placeholder="Optional note..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={3}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none mb-4"
            />
            <div className="flex gap-3">
              <button onClick={() => setActionModal(null)}
                className="flex-1 border border-gray-300 rounded-lg py-2 text-sm font-medium hover:bg-gray-50">
                Cancel
              </button>
              <button
                onClick={handleAction}
                disabled={updateMutation.isPending}
                className={`flex-1 text-white rounded-lg py-2 text-sm font-medium disabled:opacity-50 ${
                  actionModal.action === "approved" ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"
                }`}
              >
                {updateMutation.isPending ? "Processing..." : actionModal.action === "approved" ? "Approve" : "Reject"}
              </button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}
