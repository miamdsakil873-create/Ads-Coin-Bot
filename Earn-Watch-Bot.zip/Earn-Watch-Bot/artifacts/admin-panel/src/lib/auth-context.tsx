import { createContext, useContext, useState, useEffect, type ReactNode } from "react";

interface AuthContextValue {
  token: string | null;
  username: string | null;
  login: (token: string, username: string) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem("adminToken"));
  const [username, setUsername] = useState<string | null>(() => localStorage.getItem("adminUsername"));

  useEffect(() => {
    const originalFetch = window.fetch;
    window.fetch = async (input: RequestInfo | URL, init: RequestInit = {}) => {
      const t = localStorage.getItem("adminToken");
      const url = typeof input === "string" ? input : input instanceof URL ? input.toString() : (input as Request).url;
      if (t && url.includes("/api/")) {
        init = {
          ...init,
          headers: {
            ...(init.headers as Record<string, string> ?? {}),
            "x-admin-token": t,
          },
        };
      }
      return originalFetch(input, init);
    };
    return () => { window.fetch = originalFetch; };
  }, []);

  const login = (t: string, u: string) => {
    localStorage.setItem("adminToken", t);
    localStorage.setItem("adminUsername", u);
    setToken(t);
    setUsername(u);
  };

  const logout = () => {
    localStorage.removeItem("adminToken");
    localStorage.removeItem("adminUsername");
    setToken(null);
    setUsername(null);
  };

  return (
    <AuthContext.Provider value={{ token, username, login, logout, isAuthenticated: !!token }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
