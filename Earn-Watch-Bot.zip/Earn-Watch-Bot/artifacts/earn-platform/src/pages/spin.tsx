import { useState, useEffect } from "react";
import { useTelegram } from "@/lib/telegram-context";
import { Layout } from "@/components/layout";
import { SpinWheel as SpinWheelComponent } from "@/components/spin-wheel";
import { 
  useSpinWheel, 
  useGetDashboardSummary, 
  getGetDashboardSummaryQueryKey,
  getGetMeQueryKey
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { useQueryClient } from "@tanstack/react-query";
import { Gift } from "lucide-react";
import confetti from "canvas-confetti";

const SEGMENTS = [
  { id: "1", label: "10 C", value: 10, color: "#8b5cf6" }, // primary
  { id: "2", label: "0 C", value: 0, color: "#3f3f46" },   // muted
  { id: "3", label: "50 C", value: 50, color: "#ec4899" }, // pink
  { id: "4", label: "5 C", value: 5, color: "#0ea5e9" },   // cyan
  { id: "5", label: "100 C", value: 100, color: "#eab308" }, // yellow
  { id: "6", label: "0 C", value: 0, color: "#3f3f46" },   // muted
  { id: "7", label: "25 C", value: 25, color: "#22c55e" }, // green
  { id: "8", label: "10 C", value: 10, color: "#f97316" }, // orange
];

export default function Spin() {
  const { telegramId } = useTelegram();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [isSpinning, setIsSpinning] = useState(false);
  const [targetIndex, setTargetIndex] = useState<number | null>(null);

  const { data: summary } = useGetDashboardSummary(
    { telegramId },
    {
      query: {
        enabled: !!telegramId,
        queryKey: getGetDashboardSummaryQueryKey({ telegramId })
      }
    }
  );

  const spinMutation = useSpinWheel();

  const handleSpin = () => {
    if (!summary?.spinAvailable) {
      toast({
        title: "No spins available",
        description: "Complete more tasks to earn spins!",
        variant: "destructive"
      });
      return;
    }

    if (isSpinning) return;
    
    setIsSpinning(true);
    
    spinMutation.mutate({ data: { telegramId } }, {
      onSuccess: (res) => {
        // Map backend slotIndex or map prize amount to a segment
        let index = res.slotIndex;
        if (index === undefined || index < 0 || index >= SEGMENTS.length) {
          // fallback mapping by amount
          index = SEGMENTS.findIndex(s => s.value === res.coinsEarned) || 0;
        }
        setTargetIndex(index);
      },
      onError: (err: any) => {
        setIsSpinning(false);
        toast({
          title: "Spin failed",
          description: err?.message || "Please try again later.",
          variant: "destructive"
        });
      }
    });
  };

  const onSpinEnd = (prizeLabel: string) => {
    setIsSpinning(false);
    const earned = spinMutation.data?.coinsEarned || 0;
    
    if (earned > 0) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#eab308', '#8b5cf6', '#ec4899']
      });
      
      toast({
        title: "Congratulations! 🎉",
        description: `You won ${earned} coins!`,
        className: "bg-green-500 text-white border-none",
      });
    } else {
      toast({
        title: "Better luck next time",
        description: "You didn't win anything this time.",
        variant: "default",
      });
    }

    queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey({ telegramId }) });
    queryClient.invalidateQueries({ queryKey: getGetMeQueryKey({ telegramId }) });
  };

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center min-h-[70vh] py-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/20 text-primary mb-4 border border-primary/30 primary-glow">
            <Gift className="w-8 h-8" />
          </div>
          <h1 className="text-3xl font-black mb-2">Lucky Spin</h1>
          <p className="text-muted-foreground">Test your luck and win up to 1000 coins</p>
        </div>

        <div className="mb-12 mt-4 relative">
          <SpinWheelComponent 
            segments={SEGMENTS}
            isSpinning={isSpinning}
            targetIndex={targetIndex ?? undefined}
            onSpinEnd={onSpinEnd}
          />
        </div>

        <div className="w-full max-w-sm px-4">
          <Button 
            onClick={handleSpin}
            disabled={isSpinning || !summary?.spinAvailable}
            className={`w-full h-16 text-xl font-black rounded-2xl shadow-xl transition-all ${
              summary?.spinAvailable && !isSpinning
                ? "bg-gradient-to-r from-primary to-accent hover:opacity-90 primary-glow text-white" 
                : "bg-muted text-muted-foreground border-border"
            }`}
          >
            {isSpinning ? "Spinning..." : summary?.spinAvailable ? "SPIN NOW" : "No Spins Available"}
          </Button>
          
          {!summary?.spinAvailable && (
            <p className="text-center text-sm text-muted-foreground mt-4">
              Complete daily tasks to unlock more spins!
            </p>
          )}
        </div>
        
      </div>
    </Layout>
  );
}
