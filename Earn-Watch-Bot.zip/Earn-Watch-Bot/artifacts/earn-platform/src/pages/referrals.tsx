import { useState } from "react";
import { useTelegram } from "@/lib/telegram-context";
import { Layout } from "@/components/layout";
import { useGetReferrals, getGetReferralsQueryKey } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Copy, Share2, Users, Network, Award } from "lucide-react";
import { AnimatedNumber } from "@/components/animated-number";

export default function Referrals() {
  const { telegramId } = useTelegram();
  const { toast } = useToast();

  const { data: stats, isLoading } = useGetReferrals(
    { telegramId },
    {
      query: {
        enabled: !!telegramId,
        queryKey: getGetReferralsQueryKey({ telegramId })
      }
    }
  );

  const copyToClipboard = () => {
    if (!stats?.referralLink) return;
    navigator.clipboard.writeText(stats.referralLink);
    toast({
      title: "Copied!",
      description: "Referral link copied to clipboard.",
    });
  };

  const shareLink = () => {
    if (!stats?.referralLink) return;
    if (navigator.share) {
      navigator.share({
        title: 'Earn money watching ads!',
        text: 'Join this awesome bot and earn real money by watching ads.',
        url: stats.referralLink,
      }).catch((err) => console.log('Share failed', err));
    } else {
      copyToClipboard();
    }
  };

  return (
    <Layout>
      <div className="space-y-6 pb-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
        
        {/* Header */}
        <div className="glass-card rounded-3xl p-6 relative overflow-hidden bg-gradient-to-br from-blue-600/20 to-purple-600/20 border-blue-500/20">
          <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
            <Users className="w-24 h-24 rotate-12 text-blue-500" />
          </div>
          <div className="relative z-10">
            <h2 className="text-2xl font-black mb-2 text-white">Invite Friends</h2>
            <p className="text-sm text-blue-200 mb-6">
              Earn 10% from your direct referrals, and up to 3 levels deep!
            </p>
            
            <div className="bg-background/50 backdrop-blur-md rounded-2xl p-4 border border-white/10 flex items-center gap-3">
              <div className="flex-1 overflow-hidden">
                <p className="text-xs text-muted-foreground uppercase font-bold mb-1 tracking-wider">Your Referral Link</p>
                <p className="text-sm font-mono truncate text-white">
                  {isLoading ? <Skeleton className="h-5 w-full" /> : stats?.referralLink}
                </p>
              </div>
              <Button size="icon" variant="secondary" onClick={copyToClipboard} className="shrink-0 rounded-xl">
                <Copy className="w-4 h-4" />
              </Button>
              <Button size="icon" onClick={shareLink} className="shrink-0 rounded-xl bg-blue-600 hover:bg-blue-700 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)]">
                <Share2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          <div className="glass-card rounded-3xl p-5 text-center">
            <div className="w-10 h-10 rounded-full bg-primary/20 text-primary flex items-center justify-center mx-auto mb-2">
              <Users className="w-5 h-5" />
            </div>
            <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Total Invited</p>
            <p className="text-2xl font-black">
              {isLoading ? <Skeleton className="h-8 w-16 mx-auto" /> : stats?.totalReferrals}
            </p>
          </div>
          <div className="glass-card rounded-3xl p-5 text-center">
            <div className="w-10 h-10 rounded-full bg-secondary/20 text-secondary flex items-center justify-center mx-auto mb-2">
              <Award className="w-5 h-5" />
            </div>
            <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Total Earned</p>
            <p className="text-2xl font-black text-secondary">
              {isLoading ? <Skeleton className="h-8 w-16 mx-auto" /> : <AnimatedNumber value={stats?.totalEarnedFromReferrals || 0} />}
            </p>
          </div>
        </div>

        {/* Level Breakdown */}
        <Card className="glass-card border-white/5">
          <CardHeader className="pb-3 border-b border-white/5">
            <CardTitle className="text-base flex items-center gap-2">
              <Network className="w-5 h-5 text-primary" /> 3-Tier System
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-500 flex items-center justify-center font-bold text-xs">L1</div>
                <div>
                  <p className="font-bold text-sm">Direct Referrals</p>
                  <p className="text-xs text-muted-foreground">10% commission</p>
                </div>
              </div>
              <span className="font-black">{isLoading ? "-" : stats?.level1Referrals}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-purple-500/20 text-purple-500 flex items-center justify-center font-bold text-xs">L2</div>
                <div>
                  <p className="font-bold text-sm">2nd Level</p>
                  <p className="text-xs text-muted-foreground">5% commission</p>
                </div>
              </div>
              <span className="font-black">{isLoading ? "-" : stats?.level2Referrals}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-pink-500/20 text-pink-500 flex items-center justify-center font-bold text-xs">L3</div>
                <div>
                  <p className="font-bold text-sm">3rd Level</p>
                  <p className="text-xs text-muted-foreground">2% commission</p>
                </div>
              </div>
              <span className="font-black">{isLoading ? "-" : stats?.level3Referrals}</span>
            </div>
          </CardContent>
        </Card>

        {/* Recent Referrals List */}
        <div>
          <h3 className="font-bold px-2 text-lg mb-3">Recent Referrals</h3>
          {isLoading ? (
            <Skeleton className="h-32 w-full rounded-3xl" />
          ) : stats?.referralList && stats.referralList.length > 0 ? (
            <div className="glass-card rounded-3xl overflow-hidden border-white/5 divide-y divide-white/5">
              {stats.referralList.map((ref, idx) => (
                <div key={idx} className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-muted-foreground font-bold">
                      {ref.username.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="font-bold text-sm">{ref.username}</p>
                      <p className="text-xs text-muted-foreground">Level {ref.level} • {new Date(ref.joinedAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-bold text-secondary">+{ref.earnedCoins}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center p-8 glass-card rounded-3xl border-white/5">
              <p className="text-muted-foreground text-sm">No referrals yet. Share your link to start earning!</p>
            </div>
          )}
        </div>

      </div>
    </Layout>
  );
}
