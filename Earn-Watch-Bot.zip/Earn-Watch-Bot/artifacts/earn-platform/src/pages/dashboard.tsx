import { useState } from "react";
import { useTelegram } from "@/lib/telegram-context";
import { Layout } from "@/components/layout";
import { 
  useGetDashboardSummary, 
  getGetDashboardSummaryQueryKey 
} from "@workspace/api-client-react";
import { AnimatedNumber } from "@/components/animated-number";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { 
  Trophy, 
  Flame, 
  ArrowRight, 
  PlaySquare, 
  BellRing, 
  Gift, 
  Users,
  Wallet
} from "lucide-react";

export default function Dashboard() {
  const { telegramId } = useTelegram();
  const { data: summary, isLoading } = useGetDashboardSummary(
    { telegramId },
    {
      query: {
        enabled: !!telegramId,
        queryKey: getGetDashboardSummaryQueryKey({ telegramId })
      }
    }
  );

  return (
    <Layout>
      <div className="space-y-6 pb-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
        
        {/* Hero Balance Card */}
        <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-primary/90 to-accent p-6 text-white primary-glow border border-white/10">
          <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
            <Trophy className="w-32 h-32 rotate-12" />
          </div>
          
          <div className="relative z-10">
            <p className="text-sm font-medium text-white/80 uppercase tracking-wider mb-1">
              Total Balance
            </p>
            <div className="flex items-baseline gap-2 mb-4">
              <span className="text-5xl font-black tracking-tighter">
                {isLoading ? <Skeleton className="h-12 w-32 bg-white/20" /> : <AnimatedNumber value={summary?.balance || 0} />}
              </span>
              <span className="text-xl font-bold text-secondary drop-shadow-md">Coins</span>
            </div>
            
            <div className="flex gap-4">
              <Link href="/withdraw" className="flex-1 bg-white/20 hover:bg-white/30 transition-colors rounded-xl py-3 px-4 flex items-center justify-center gap-2 backdrop-blur-md border border-white/10 font-bold active:scale-95 duration-200">
                <Wallet className="w-5 h-5" />
                Withdraw
              </Link>
            </div>
          </div>
        </div>

        {/* Daily Progress */}
        <div className="glass-card rounded-3xl p-5">
          <div className="flex justify-between items-end mb-3">
            <div>
              <h3 className="font-bold text-lg flex items-center gap-2">
                Daily Quests
                {summary?.streakDays ? (
                  <span className="flex items-center gap-1 text-xs bg-orange-500/20 text-orange-500 px-2 py-0.5 rounded-full border border-orange-500/30">
                    <Flame className="w-3 h-3" /> {summary.streakDays} Day Streak
                  </span>
                ) : null}
              </h3>
              <p className="text-sm text-muted-foreground">
                Complete all tasks for a bonus!
              </p>
            </div>
            <div className="text-right">
              <span className="font-black text-xl text-primary">
                {isLoading ? "-" : summary?.tasksCompletedToday}
              </span>
              <span className="text-muted-foreground font-medium">/{isLoading ? "-" : summary?.totalTasksToday}</span>
            </div>
          </div>
          
          <div className="h-4 bg-muted rounded-full overflow-hidden mb-4 border border-border/50">
            <div 
              className="h-full bg-gradient-to-r from-primary to-secondary transition-all duration-1000 ease-out"
              style={{ width: `${summary?.dailyProgress || 0}%` }}
            />
          </div>
          
          <Link href="/tasks" className="w-full bg-secondary text-secondary-foreground hover:brightness-110 font-bold rounded-xl py-3 px-4 flex items-center justify-between transition-all active:scale-95">
            <span className="flex items-center gap-2">
              <PlaySquare className="w-5 h-5" />
              Start Watching Ads
            </span>
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>

        {/* Quick Actions Grid */}
        <div className="grid grid-cols-2 gap-4">
          <Link href="/spin" className="glass-card rounded-3xl p-5 flex flex-col items-center justify-center gap-3 text-center transition-transform active:scale-95 relative overflow-hidden group">
            {summary?.spinAvailable && (
              <span className="absolute top-3 right-3 w-3 h-3 bg-red-500 rounded-full animate-pulse" />
            )}
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
              <Gift className="w-7 h-7 text-white" />
            </div>
            <div>
              <h4 className="font-bold">Spin Wheel</h4>
              <p className="text-xs text-muted-foreground font-medium">Win up to 1000</p>
            </div>
          </Link>

          <Link href="/referrals" className="glass-card rounded-3xl p-5 flex flex-col items-center justify-center gap-3 text-center transition-transform active:scale-95 group">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
              <Users className="w-7 h-7 text-white" />
            </div>
            <div>
              <h4 className="font-bold">Invite Friends</h4>
              <p className="text-xs text-muted-foreground font-medium">{summary?.referralCount || 0} referred</p>
            </div>
          </Link>
        </div>

        {/* Announcements */}
        {summary?.announcements && summary.announcements.length > 0 && (
          <div className="space-y-3">
            <h3 className="font-bold text-lg px-2 flex items-center gap-2">
              <BellRing className="w-5 h-5 text-primary" /> Updates
            </h3>
            {summary.announcements.map((ann) => (
              <div 
                key={ann.id} 
                className={`rounded-2xl p-4 border ${
                  ann.type === 'success' ? 'bg-green-500/10 border-green-500/20 text-green-500' :
                  ann.type === 'warning' ? 'bg-orange-500/10 border-orange-500/20 text-orange-500' :
                  'bg-blue-500/10 border-blue-500/20 text-blue-500'
                }`}
              >
                <h4 className="font-bold mb-1">{ann.title}</h4>
                <p className="text-sm opacity-90 leading-relaxed">{ann.message}</p>
              </div>
            ))}
          </div>
        )}

      </div>
    </Layout>
  );
}
