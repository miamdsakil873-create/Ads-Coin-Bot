import { useState } from "react";
import { useTelegram } from "@/lib/telegram-context";
import { Layout } from "@/components/layout";
import { ScratchCard } from "@/components/scratch-card";
import { 
  useScratchCard, 
  useGetDashboardSummary, 
  getGetDashboardSummaryQueryKey,
  getGetMeQueryKey
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Sparkles, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import confetti from "canvas-confetti";

export default function Scratch() {
  const { telegramId } = useTelegram();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [isScratched, setIsScratched] = useState(false);
  const [prize, setPrize] = useState<{ amount: number; label: string } | null>(null);

  const { data: summary } = useGetDashboardSummary(
    { telegramId },
    {
      query: {
        enabled: !!telegramId,
        queryKey: getGetDashboardSummaryQueryKey({ telegramId })
      }
    }
  );

  const scratchMutation = useScratchCard();

  const handleScratchComplete = () => {
    if (!summary?.scratchAvailable) return;
    
    scratchMutation.mutate({ data: { telegramId } }, {
      onSuccess: (res) => {
        setIsScratched(true);
        setPrize({ amount: res.coinsEarned, label: res.prize });
        
        if (res.coinsEarned > 0) {
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 }
          });
        }
        
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey({ telegramId }) });
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey({ telegramId }) });
      },
      onError: (err: any) => {
        toast({
          title: "Error",
          description: err?.message || "Failed to process scratch card.",
          variant: "destructive"
        });
      }
    });
  };

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center min-h-[70vh] py-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-secondary/20 text-secondary mb-4 border border-secondary/30 gold-glow">
            <Sparkles className="w-8 h-8" />
          </div>
          <h1 className="text-3xl font-black mb-2">Scratch & Win</h1>
          <p className="text-muted-foreground">Reveal hidden prizes daily</p>
        </div>

        {summary?.scratchAvailable ? (
          <div className="mb-8">
            <ScratchCard 
              width={320} 
              height={180} 
              onComplete={handleScratchComplete}
              isCompleted={isScratched}
            >
              <div className="text-center w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-card to-card p-4">
                {prize ? (
                  prize.amount > 0 ? (
                    <div className="animate-in zoom-in duration-500">
                      <p className="text-sm font-bold text-muted-foreground mb-1 uppercase tracking-widest">{prize.label}</p>
                      <div className="flex items-center justify-center gap-2">
                        <span className="text-5xl font-black text-secondary drop-shadow-md">{prize.amount}</span>
                        <span className="text-xl font-bold text-white">Coins</span>
                      </div>
                    </div>
                  ) : (
                    <div className="animate-in zoom-in duration-500">
                      <p className="text-2xl font-bold text-muted-foreground">Try Again</p>
                    </div>
                  )
                ) : (
                  <div className="animate-pulse">Processing...</div>
                )}
              </div>
            </ScratchCard>
            
            <p className="text-center text-sm text-muted-foreground mt-6 font-medium animate-pulse">
              {isScratched ? "Come back tomorrow for another card!" : "Scratch the card to reveal your prize"}
            </p>
          </div>
        ) : (
          <div className="text-center p-8 glass-card rounded-3xl max-w-sm w-full mx-4 border-white/5">
            <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <Sparkles className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-bold mb-2">No Cards Available</h3>
            <p className="text-muted-foreground text-sm mb-6">
              You've scratched all your cards for today. Complete tasks to earn more!
            </p>
            <Button asChild className="w-full rounded-xl">
              <Link href="/tasks">Go to Tasks <ArrowRight className="w-4 h-4 ml-2" /></Link>
            </Button>
          </div>
        )}
      </div>
    </Layout>
  );
}
