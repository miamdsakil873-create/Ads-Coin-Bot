import { useState, useEffect, useRef } from "react";
import { useTelegram } from "@/lib/telegram-context";
import { Layout } from "@/components/layout";
import { useGetTasks, useCompleteTask, getGetTasksQueryKey, getGetDashboardSummaryQueryKey, getGetMeQueryKey } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle2, PlaySquare, ArrowRight, ExternalLink, Gift, LogIn } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

export default function Tasks() {
  const { telegramId } = useTelegram();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTask, setActiveTask] = useState<number | null>(null);
  const [countdown, setCountdown] = useState(0);

  const { data: tasks, isLoading } = useGetTasks(
    { telegramId },
    {
      query: {
        enabled: !!telegramId,
        queryKey: getGetTasksQueryKey({ telegramId })
      }
    }
  );

  const completeTaskMutation = useCompleteTask();

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (activeTask && countdown > 0) {
      timer = setTimeout(() => setCountdown(c => c - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [activeTask, countdown]);

  const handleStartTask = (taskId: number, taskType: string, timerSeconds: number, url?: string | null) => {
    if (taskType === 'watch_ad') {
      try {
        const w = window as any;
        if (typeof w.show_9537184 === 'function') {
          w.show_9537184();
        }
      } catch {}
    } else if (url) {
      window.open(url, "_blank");
    }
    setActiveTask(taskId);
    setCountdown(timerSeconds);
  };

  const handleCompleteTask = (taskId: number) => {
    completeTaskMutation.mutate(
      { data: { telegramId, taskId } },
      {
        onSuccess: (res) => {
          toast({
            title: "Task Completed!",
            description: res.message || `You earned ${res.coinsEarned} coins.`,
            variant: "default",
          });
          queryClient.invalidateQueries({ queryKey: getGetTasksQueryKey({ telegramId }) });
          queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey({ telegramId }) });
          queryClient.invalidateQueries({ queryKey: getGetMeQueryKey({ telegramId }) });
          setActiveTask(null);
        },
        onError: (err: any) => {
          toast({
            title: "Error",
            description: err?.message || "Failed to complete task. Try again.",
            variant: "destructive",
          });
          setActiveTask(null);
        }
      }
    );
  };

  const completedCount = tasks?.filter(t => t.isCompleted).length || 0;
  const totalCount = tasks?.length || 0;
  const progress = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;

  return (
    <Layout>
      <div className="space-y-6 pb-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
        
        <div className="glass-card rounded-3xl p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
            <CheckCircle2 className="w-24 h-24 rotate-12" />
          </div>
          <div className="relative z-10">
            <h2 className="text-2xl font-black mb-2">Daily Quests</h2>
            <p className="text-sm text-muted-foreground mb-4">
              Complete tasks to earn coins and unlock the spin wheel.
            </p>
            
            <div className="flex justify-between items-end mb-2">
              <span className="font-bold text-sm">Progress</span>
              <span className="font-black text-primary">{completedCount}/{totalCount}</span>
            </div>
            <Progress value={progress} className="h-3 bg-muted border border-border/50" />
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="font-bold px-2 text-lg">Available Tasks</h3>
          
          {isLoading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <Card key={i} className="rounded-2xl border-white/5 bg-card/40">
                <CardContent className="p-4 flex gap-4 items-center">
                  <Skeleton className="w-12 h-12 rounded-xl" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-3 w-1/2" />
                  </div>
                </CardContent>
              </Card>
            ))
          ) : tasks?.length === 0 ? (
            <div className="text-center p-8 glass-card rounded-3xl">
              <CheckCircle2 className="w-12 h-12 text-primary mx-auto mb-3 opacity-50" />
              <h4 className="font-bold">All Caught Up!</h4>
              <p className="text-sm text-muted-foreground mt-1">Check back tomorrow for more tasks.</p>
            </div>
          ) : (
            tasks?.map((task) => (
              <Card 
                key={task.id} 
                className={`rounded-2xl transition-all duration-300 border-white/5 ${
                  task.isCompleted ? "opacity-50 grayscale bg-card/20" : "bg-card/40 hover:bg-card/60"
                }`}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      task.isCompleted ? "bg-muted text-muted-foreground" : "bg-primary/20 text-primary border border-primary/30"
                    }`}>
                      {task.taskType === 'watch_ad' ? <PlaySquare className="w-6 h-6" /> :
                       task.taskType === 'daily_login' ? <LogIn className="w-6 h-6" /> :
                       task.taskType === 'signup_bonus' ? <Gift className="w-6 h-6" /> :
                       <ExternalLink className="w-6 h-6" />}
                    </div>
                    
                    <div className="flex-1">
                      <h4 className="font-bold text-sm leading-tight">{task.title}</h4>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{task.description}</p>
                      <div className="flex items-center gap-1 mt-1.5">
                        <div className="w-3 h-3 rounded-full bg-secondary flex items-center justify-center">
                          <span className="text-[8px] font-black text-secondary-foreground">C</span>
                        </div>
                        <span className="text-xs font-bold text-secondary">+{task.rewardCoins}</span>
                      </div>
                    </div>
                  </div>

                  {!task.isCompleted && (
                    <div className="mt-4">
                      {activeTask === task.id ? (
                        countdown > 0 ? (
                          <Button disabled className="w-full rounded-xl font-bold bg-muted text-muted-foreground border border-border">
                            Wait {countdown}s...
                          </Button>
                        ) : (
                          <Button 
                            onClick={() => handleCompleteTask(task.id)}
                            disabled={completeTaskMutation.isPending}
                            className="w-full rounded-xl font-bold bg-green-500 hover:bg-green-600 text-white shadow-[0_0_15px_rgba(34,197,94,0.3)] animate-in zoom-in duration-300"
                          >
                            {completeTaskMutation.isPending ? "Claiming..." : "Claim Reward"}
                          </Button>
                        )
                      ) : (
                        <Button 
                          onClick={() => handleStartTask(task.id, task.taskType, task.timerSeconds, task.adUrl || task.linkUrl)}
                          className="w-full rounded-xl font-bold bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30"
                          variant="secondary"
                        >
                          {task.buttonText || (task.taskType === 'watch_ad' ? 'Watch Ad' : 'Start Task')} <ArrowRight className="w-4 h-4 ml-1" />
                        </Button>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </Layout>
  );
}
