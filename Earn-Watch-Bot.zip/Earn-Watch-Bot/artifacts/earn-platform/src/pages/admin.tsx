import { useState } from "react";
import { useLocation } from "wouter";
import { useTelegram } from "@/lib/telegram-context";
import { Layout } from "@/components/layout";
import { 
  useAdminGetStats, 
  useAdminGetWithdrawals, 
  useAdminUpdateWithdrawalStatus,
  useAdminPostAnnouncement,
  useGetMe,
  getAdminGetStatsQueryKey,
  getAdminGetWithdrawalsQueryKey,
  getGetMeQueryKey,
  UpdateWithdrawalStatusBodyStatus,
  AnnouncementBodyType
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useQueryClient } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export default function Admin() {
  const { telegramId } = useTelegram();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: user, isLoading: isUserLoading } = useGetMe({ telegramId }, {
    query: {
      enabled: !!telegramId,
      queryKey: getGetMeQueryKey({ telegramId })
    }
  });

  const { data: stats } = useAdminGetStats({
    query: {
      enabled: user?.isAdmin,
      queryKey: getAdminGetStatsQueryKey()
    }
  });

  const { data: withdrawals } = useAdminGetWithdrawals({
    query: {
      enabled: user?.isAdmin,
      queryKey: getAdminGetWithdrawalsQueryKey()
    }
  });

  const updateStatusMutation = useAdminUpdateWithdrawalStatus();
  const postAnnouncementMutation = useAdminPostAnnouncement();

  const [annTitle, setAnnTitle] = useState("");
  const [annMessage, setAnnMessage] = useState("");
  const [annType, setAnnType] = useState<string>("info");

  // Redirect if not admin
  if (!isUserLoading && user && !user.isAdmin) {
    setLocation("/");
    return null;
  }

  const handleUpdateStatus = (id: number, status: UpdateWithdrawalStatusBodyStatus) => {
    updateStatusMutation.mutate({
      id,
      data: { status }
    }, {
      onSuccess: () => {
        toast({ title: `Withdrawal ${status}` });
        queryClient.invalidateQueries({ queryKey: getAdminGetWithdrawalsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getAdminGetStatsQueryKey() });
      },
      onError: (err: any) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  const handlePostAnnouncement = () => {
    if (!annTitle || !annMessage) return;

    postAnnouncementMutation.mutate({
      data: {
        title: annTitle,
        message: annMessage,
        type: annType as AnnouncementBodyType
      }
    }, {
      onSuccess: () => {
        toast({ title: "Announcement posted!" });
        setAnnTitle("");
        setAnnMessage("");
      },
      onError: (err: any) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  if (isUserLoading) return <Layout><div className="p-8 text-center">Loading admin panel...</div></Layout>;

  return (
    <Layout>
      <div className="space-y-6 pb-6">
        <h2 className="text-2xl font-black">Admin Panel</h2>

        <Tabs defaultValue="stats">
          <TabsList className="grid grid-cols-3 w-full mb-4 bg-muted/50 p-1 rounded-xl">
            <TabsTrigger value="stats" className="rounded-lg">Stats</TabsTrigger>
            <TabsTrigger value="payouts" className="rounded-lg">Payouts</TabsTrigger>
            <TabsTrigger value="announcements" className="rounded-lg">News</TabsTrigger>
          </TabsList>

          <TabsContent value="stats" className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Card className="bg-card/40 border-white/5">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground font-bold">Total Users</p>
                  <p className="text-2xl font-black">{stats?.totalUsers || 0}</p>
                </CardContent>
              </Card>
              <Card className="bg-card/40 border-white/5">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground font-bold">Active Today</p>
                  <p className="text-2xl font-black text-primary">{stats?.activeUsersToday || 0}</p>
                </CardContent>
              </Card>
              <Card className="bg-card/40 border-white/5">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground font-bold">Tasks Done</p>
                  <p className="text-2xl font-black">{stats?.totalTasksCompleted || 0}</p>
                </CardContent>
              </Card>
              <Card className="bg-card/40 border-white/5">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground font-bold">Coins Given</p>
                  <p className="text-2xl font-black text-secondary">{stats?.totalCoinsDistributed || 0}</p>
                </CardContent>
              </Card>
              <Card className="bg-card/40 border-white/5">
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground font-bold">Total Withdrawn</p>
                  <p className="text-2xl font-black text-green-500">{stats?.totalWithdrawn || 0}</p>
                </CardContent>
              </Card>
              <Card className="bg-card/40 border-white/5 bg-orange-500/10 border-orange-500/20">
                <CardContent className="p-4">
                  <p className="text-xs text-orange-500 font-bold">Pending Payouts</p>
                  <p className="text-2xl font-black text-orange-500">{stats?.pendingWithdrawals || 0}</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="payouts">
            <div className="space-y-3">
              {withdrawals?.map(w => (
                <Card key={w.id} className="bg-card/40 border-white/5">
                  <CardContent className="p-4 space-y-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-bold">{w.amount} Coins</span>
                          <Badge variant={w.status === 'pending' ? 'default' : w.status === 'approved' ? 'secondary' : 'destructive'} 
                            className={w.status === 'pending' ? 'bg-orange-500 hover:bg-orange-500' : ''}>
                            {w.status}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">User: {w.telegramId}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-bold uppercase">{w.method}</p>
                        <p className="text-xs font-mono">{w.accountNumber}</p>
                      </div>
                    </div>
                    
                    {w.status === 'pending' && (
                      <div className="flex gap-2 pt-2 border-t border-white/5 mt-2">
                        <Button 
                          size="sm" 
                          variant="destructive" 
                          className="flex-1"
                          onClick={() => handleUpdateStatus(w.id, 'rejected')}
                          disabled={updateStatusMutation.isPending}
                        >Reject</Button>
                        <Button 
                          size="sm" 
                          className="flex-1 bg-green-500 hover:bg-green-600 text-white"
                          onClick={() => handleUpdateStatus(w.id, 'approved')}
                          disabled={updateStatusMutation.isPending}
                        >Approve</Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
              {withdrawals?.length === 0 && <p className="text-center text-muted-foreground">No requests found.</p>}
            </div>
          </TabsContent>

          <TabsContent value="announcements">
            <Card className="bg-card/40 border-white/5">
              <CardHeader>
                <CardTitle>Post Announcement</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-bold">Type</label>
                  <Select value={annType} onValueChange={setAnnType}>
                    <SelectTrigger className="bg-background/50">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="info">Info (Blue)</SelectItem>
                      <SelectItem value="success">Success (Green)</SelectItem>
                      <SelectItem value="warning">Warning (Orange)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold">Title</label>
                  <Input 
                    value={annTitle} 
                    onChange={e => setAnnTitle(e.target.value)} 
                    placeholder="E.g., Special Weekend Bonus!"
                    className="bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold">Message</label>
                  <Textarea 
                    value={annMessage} 
                    onChange={e => setAnnMessage(e.target.value)} 
                    placeholder="Enter announcement details..."
                    className="bg-background/50 min-h-[100px]"
                  />
                </div>
                <Button 
                  onClick={handlePostAnnouncement} 
                  disabled={!annTitle || !annMessage || postAnnouncementMutation.isPending}
                  className="w-full font-bold"
                >
                  Post Announcement
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
