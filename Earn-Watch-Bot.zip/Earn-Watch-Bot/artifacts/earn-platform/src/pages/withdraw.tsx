import { useState } from "react";
import { useTelegram } from "@/lib/telegram-context";
import { Layout } from "@/components/layout";
import { 
  useGetWithdrawals, 
  useRequestWithdrawal, 
  useGetDashboardSummary,
  getGetWithdrawalsQueryKey,
  getGetDashboardSummaryQueryKey,
  getGetMeQueryKey,
  WithdrawalRequestBodyMethod
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useQueryClient } from "@tanstack/react-query";
import { Wallet, Clock, CheckCircle2, XCircle, ArrowDownRight } from "lucide-react";

const withdrawalSchema = z.object({
  amount: z.coerce.number().min(1000, "Minimum withdrawal is 1000 coins"),
  method: z.enum(["bkash", "nagad", "crypto"] as const),
  accountNumber: z.string().min(5, "Account number is required"),
});

export default function Withdraw() {
  const { telegramId } = useTelegram();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: summary } = useGetDashboardSummary(
    { telegramId },
    {
      query: {
        enabled: !!telegramId,
        queryKey: getGetDashboardSummaryQueryKey({ telegramId })
      }
    }
  );

  const { data: withdrawals, isLoading: isHistoryLoading } = useGetWithdrawals(
    { telegramId },
    {
      query: {
        enabled: !!telegramId,
        queryKey: getGetWithdrawalsQueryKey({ telegramId })
      }
    }
  );

  const withdrawMutation = useRequestWithdrawal();

  const form = useForm<z.infer<typeof withdrawalSchema>>({
    resolver: zodResolver(withdrawalSchema),
    defaultValues: {
      amount: 1000,
      method: "bkash",
      accountNumber: "",
    },
  });

  const onSubmit = (values: z.infer<typeof withdrawalSchema>) => {
    if ((summary?.withdrawableBalance || 0) < values.amount) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have enough withdrawable coins.",
        variant: "destructive"
      });
      return;
    }

    withdrawMutation.mutate({
      data: {
        telegramId,
        amount: values.amount,
        method: values.method as WithdrawalRequestBodyMethod,
        accountNumber: values.accountNumber
      }
    }, {
      onSuccess: () => {
        toast({
          title: "Request Submitted",
          description: "Your withdrawal request is pending approval.",
          className: "bg-green-500 text-white"
        });
        form.reset();
        queryClient.invalidateQueries({ queryKey: getGetWithdrawalsQueryKey({ telegramId }) });
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey({ telegramId }) });
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey({ telegramId }) });
      },
      onError: (err: any) => {
        toast({
          title: "Error",
          description: err?.message || "Failed to submit request.",
          variant: "destructive"
        });
      }
    });
  };

  const getStatusIcon = (status: string) => {
    switch(status) {
      case 'approved': return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'rejected': return <XCircle className="w-5 h-5 text-red-500" />;
      default: return <Clock className="w-5 h-5 text-orange-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'approved': return "text-green-500 bg-green-500/10 border-green-500/20";
      case 'rejected': return "text-red-500 bg-red-500/10 border-red-500/20";
      default: return "text-orange-500 bg-orange-500/10 border-orange-500/20";
    }
  };

  return (
    <Layout>
      <div className="space-y-6 pb-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
        
        {/* Balance Card */}
        <div className="glass-card rounded-3xl p-6 relative overflow-hidden border-white/5">
          <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
            <Wallet className="w-24 h-24 rotate-12" />
          </div>
          <div className="relative z-10 flex flex-col items-center text-center">
            <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest mb-1">Withdrawable</p>
            <div className="flex items-center justify-center gap-2 mb-4">
              <span className="text-4xl font-black text-white drop-shadow-md">
                {summary?.withdrawableBalance.toLocaleString() || 0}
              </span>
              <span className="text-xl font-bold text-secondary">Coins</span>
            </div>
            
            <div className="w-full grid grid-cols-2 gap-2 mt-2 border-t border-white/10 pt-4">
              <div>
                <p className="text-[10px] text-muted-foreground uppercase font-bold">Total Earned</p>
                <p className="font-bold">{summary?.totalEarned.toLocaleString() || 0}</p>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground uppercase font-bold">Pending</p>
                <p className="font-bold text-orange-400">{summary?.pendingBalance.toLocaleString() || 0}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Withdrawal Form */}
        <div className="glass-card rounded-3xl p-5 border-white/5">
          <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
            <ArrowDownRight className="w-5 h-5 text-primary" /> Request Payout
          </h3>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              
              <FormField
                control={form.control}
                name="method"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>Select Method</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="grid grid-cols-3 gap-2"
                      >
                        {[
                          { id: "bkash", label: "bKash", color: "bg-[#e2136e]" },
                          { id: "nagad", label: "Nagad", color: "bg-[#f7931e]" },
                          { id: "crypto", label: "Crypto", color: "bg-[#f7931a]" }
                        ].map((m) => (
                          <FormItem key={m.id}>
                            <FormControl>
                              <RadioGroupItem value={m.id} className="peer sr-only" />
                            </FormControl>
                            <FormLabel className="flex flex-col items-center justify-center rounded-xl border-2 border-muted bg-card/50 p-3 hover:bg-card/80 peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10 cursor-pointer transition-all">
                              <div className={`w-8 h-8 rounded-full ${m.color} flex items-center justify-center text-white text-xs font-black mb-2 shadow-lg`}>
                                {m.label[0]}
                              </div>
                              <span className="text-xs font-bold">{m.label}</span>
                            </FormLabel>
                          </FormItem>
                        ))}
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="accountNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Account Details</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder={form.watch('method') === 'crypto' ? "Wallet Address (USDT TRC20)" : "Phone Number (01...)"} 
                        className="rounded-xl bg-card/50 border-white/10 h-12"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="amount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex justify-between">
                      <span>Amount (Coins)</span>
                      <span className="text-xs text-muted-foreground">Min: 1000</span>
                    </FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input 
                          type="number" 
                          className="rounded-xl bg-card/50 border-white/10 h-12 pl-10 font-bold text-lg"
                          {...field} 
                        />
                        <div className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-secondary flex items-center justify-center">
                          <span className="text-[10px] font-black text-secondary-foreground">C</span>
                        </div>
                        <Button 
                          type="button"
                          variant="ghost" 
                          size="sm"
                          className="absolute right-2 top-1/2 -translate-y-1/2 h-8 text-xs font-bold text-primary hover:text-primary hover:bg-primary/20"
                          onClick={() => form.setValue('amount', summary?.withdrawableBalance || 0)}
                        >
                          MAX
                        </Button>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                disabled={withdrawMutation.isPending}
                className="w-full h-14 rounded-xl font-black text-lg bg-primary hover:bg-primary/90 text-white shadow-[0_0_20px_rgba(139,92,246,0.3)] transition-all active:scale-95"
              >
                {withdrawMutation.isPending ? "PROCESSING..." : "WITHDRAW NOW"}
              </Button>
            </form>
          </Form>
        </div>

        {/* History */}
        <div>
          <h3 className="font-bold px-2 text-lg mb-3">History</h3>
          {isHistoryLoading ? (
            <Skeleton className="h-32 w-full rounded-3xl" />
          ) : withdrawals && withdrawals.length > 0 ? (
            <div className="glass-card rounded-3xl overflow-hidden border-white/5 divide-y divide-white/5">
              {withdrawals.map((w) => (
                <div key={w.id} className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(w.status)}
                    <div>
                      <p className="font-bold text-sm uppercase">{w.method}</p>
                      <p className="text-xs text-muted-foreground">{new Date(w.createdAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-black">{w.amount} C</p>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase border ${getStatusColor(w.status)}`}>
                      {w.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center p-8 glass-card rounded-3xl border-white/5">
              <p className="text-muted-foreground text-sm">No withdrawal history yet.</p>
            </div>
          )}
        </div>

      </div>
    </Layout>
  );
}
