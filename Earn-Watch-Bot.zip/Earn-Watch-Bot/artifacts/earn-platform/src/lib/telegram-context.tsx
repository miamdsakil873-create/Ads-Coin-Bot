import { createContext, useContext, ReactNode, useState, useEffect } from "react";
import { useRegisterUser, useGetMe } from "@workspace/api-client-react";

interface TelegramContextType {
  telegramId: string;
  isRegistered: boolean;
  isLoading: boolean;
}

const TelegramContext = createContext<TelegramContextType>({
  telegramId: "123456789", // Mock ID
  isRegistered: false,
  isLoading: true,
});

export const useTelegram = () => useContext(TelegramContext);

export function TelegramProvider({ children }: { children: ReactNode }) {
  const telegramId = "123456789"; // Mock user for demo
  const [isRegistered, setIsRegistered] = useState(false);
  const [isReady, setIsReady] = useState(false);

  const registerMutation = useRegisterUser();
  
  const { data: user, isLoading: isUserLoading, error } = useGetMe({ telegramId }, {
    query: {
      enabled: true,
      retry: false
    }
  });

  useEffect(() => {
    if (!isUserLoading) {
      if (user) {
        setIsRegistered(true);
        setIsReady(true);
      } else if (error) {
        // Need to register
        registerMutation.mutate({
          data: {
            telegramId,
            username: "DemoUser",
            firstName: "Demo",
            lastName: "User"
          }
        }, {
          onSuccess: () => {
            setIsRegistered(true);
            setIsReady(true);
          },
          onError: () => {
            // Assume registered if it fails with 400
            setIsRegistered(true);
            setIsReady(true);
          }
        });
      }
    }
  }, [user, isUserLoading, error, telegramId]);

  return (
    <TelegramContext.Provider value={{ telegramId, isRegistered, isLoading: !isReady }}>
      {children}
    </TelegramContext.Provider>
  );
}
