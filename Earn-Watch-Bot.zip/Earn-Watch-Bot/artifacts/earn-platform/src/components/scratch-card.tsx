import { useRef, useEffect, useState } from 'react';

interface ScratchCardProps {
  width?: number;
  height?: number;
  coverColor?: string;
  onComplete: () => void;
  children: React.ReactNode;
  isCompleted?: boolean;
}

export function ScratchCard({
  width = 300,
  height = 150,
  coverColor = '#4c1d95', // Primary dark purple
  onComplete,
  children,
  isCompleted = false
}: ScratchCardProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [percentScratched, setPercentScratched] = useState(0);
  const [revealed, setRevealed] = useState(isCompleted);

  // Initialize canvas
  useEffect(() => {
    if (revealed || isCompleted) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Fill cover
    ctx.fillStyle = coverColor;
    ctx.fillRect(0, 0, width, height);

    // Add some pattern/text to cover
    ctx.font = "bold 24px 'Plus Jakarta Sans', sans-serif";
    ctx.fillStyle = "rgba(255, 255, 255, 0.5)";
    ctx.textAlign = "center";
    ctx.fillText("SCRATCH ME", width / 2, height / 2);
    
    // Pattern
    for(let i=0; i<50; i++) {
      ctx.beginPath();
      ctx.arc(Math.random() * width, Math.random() * height, Math.random() * 5 + 1, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255, 255, 255, 0.1)";
      ctx.fill();
    }

  }, [width, height, coverColor, revealed, isCompleted]);

  const getPosition = (e: React.MouseEvent | React.TouchEvent | MouseEvent | TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    let clientX, clientY;
    
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    }

    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  };

  const scratch = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || revealed) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const pos = getPosition(e);
    
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, 20, 0, Math.PI * 2);
    ctx.fill();

    // Check percentage scratched every few strokes
    if (Math.random() > 0.8) {
      calculateScratchedPercentage();
    }
  };

  const calculateScratchedPercentage = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const pixels = ctx.getImageData(0, 0, width, height).data;
    let transparentPixels = 0;
    const totalPixels = pixels.length / 4;

    for (let i = 3; i < pixels.length; i += 4) {
      if (pixels[i] === 0) {
        transparentPixels++;
      }
    }

    const percentage = (transparentPixels / totalPixels) * 100;
    setPercentScratched(percentage);

    if (percentage > 50 && !revealed) {
      setRevealed(true);
      onComplete();
    }
  };

  const handleStart = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDrawing(true);
    scratch(e);
  };

  const handleEnd = () => {
    setIsDrawing(false);
  };

  return (
    <div 
      ref={containerRef}
      className="relative overflow-hidden rounded-2xl border-4 border-white/10 shadow-xl"
      style={{ width, height, userSelect: 'none', touchAction: 'none' }}
    >
      {/* Background/Revealed Content */}
      <div className="absolute inset-0 flex items-center justify-center bg-card">
        {children}
      </div>

      {/* Canvas Cover */}
      {(!revealed && !isCompleted) && (
        <canvas
          ref={canvasRef}
          width={width}
          height={height}
          className={`absolute inset-0 cursor-pointer transition-opacity duration-1000 ${revealed ? 'opacity-0' : 'opacity-100'}`}
          onMouseDown={handleStart}
          onMouseMove={scratch}
          onMouseUp={handleEnd}
          onMouseLeave={handleEnd}
          onTouchStart={handleStart}
          onTouchMove={scratch}
          onTouchEnd={handleEnd}
        />
      )}
    </div>
  );
}
