import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Home, ListTodo, Gift, Users, Wallet, ShieldAlert } from "lucide-react";
import { useTelegram } from "@/lib/telegram-context";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { telegramId } = useTelegram();
  const { data: user } = useGetMe({ telegramId }, {
    query: {
      enabled: !!telegramId,
      queryKey: getGetMeQueryKey({ telegramId })
    }
  });

  const navItems = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/tasks", icon: ListTodo, label: "Tasks" },
    { href: "/spin", icon: Gift, label: "Rewards" },
    { href: "/referrals", icon: Users, label: "Friends" },
    { href: "/withdraw", icon: Wallet, label: "Wallet" },
  ];

  if (user?.isAdmin) {
    navItems.push({ href: "/admin", icon: ShieldAlert, label: "Admin" });
  }

  return (
    <div className="min-h-[100dvh] w-full bg-background flex justify-center text-foreground dark">
      <div className="w-full max-w-[480px] min-h-[100dvh] flex flex-col relative shadow-2xl bg-background border-x border-border/50">
        
        {/* Header Header */}
        <header className="h-16 flex items-center px-4 justify-between glass-card sticky top-0 z-50 rounded-b-2xl">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold shadow-inner border border-primary/30">
              {user?.firstName?.charAt(0) || "U"}
            </div>
            <div>
              <p className="text-xs text-muted-foreground font-medium">Welcome back,</p>
              <p className="text-sm font-bold leading-tight">{user?.firstName || "User"}</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 bg-secondary/10 px-3 py-1.5 rounded-full border border-secondary/20">
            <div className="w-4 h-4 rounded-full bg-secondary flex items-center justify-center animate-pulse-ring">
              <span className="text-[10px] font-black text-secondary-foreground">C</span>
            </div>
            <span className="font-bold text-secondary">{user?.balance?.toLocaleString() || 0}</span>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto pb-24 px-4 pt-6 no-scrollbar relative">
          {children}
        </main>

        {/* Bottom Navigation */}
        <nav className="fixed bottom-0 w-full max-w-[480px] h-20 glass-card rounded-t-3xl border-t border-white/5 flex items-center justify-around px-2 pb-safe z-50">
          {navItems.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            
            return (
              <Link 
                key={item.href} 
                href={item.href}
                className={`flex flex-col items-center justify-center w-16 h-16 rounded-2xl transition-all duration-300 relative ${
                  isActive 
                    ? "text-primary -translate-y-2" 
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {isActive && (
                  <div className="absolute inset-0 bg-primary/10 rounded-2xl animate-in fade-in zoom-in duration-300" />
                )}
                <Icon 
                  className={`w-6 h-6 mb-1 transition-all duration-300 ${
                    isActive ? "drop-shadow-[0_0_8px_rgba(139,92,246,0.5)]" : ""
                  }`} 
                />
                <span className={`text-[10px] font-semibold transition-all duration-300 ${
                  isActive ? "opacity-100" : "opacity-70"
                }`}>
                  {item.label}
                </span>
                {isActive && (
                  <div className="absolute -bottom-2 w-1 h-1 rounded-full bg-primary" />
                )}
              </Link>
            );
          })}
        </nav>
        
        {/* Safe area spacing for mobile */}
        <div className="h-safe-bottom w-full bg-background fixed bottom-0 z-40 max-w-[480px]" />
      </div>
    </div>
  );
}
