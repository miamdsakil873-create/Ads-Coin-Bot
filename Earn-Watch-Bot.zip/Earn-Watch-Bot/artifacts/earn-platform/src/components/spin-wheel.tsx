import { useState } from "react";
import { motion, useAnimation } from "framer-motion";

interface SpinWheelProps {
  segments: { id: string; label: string; color: string; value: number }[];
  onSpinEnd: (prize: string) => void;
  isSpinning: boolean;
  targetIndex?: number;
}

export function SpinWheel({ segments, onSpinEnd, isSpinning, targetIndex }: SpinWheelProps) {
  const [rotation, setRotation] = useState(0);
  const controls = useAnimation();
  
  const segmentAngle = 360 / segments.length;
  
  if (isSpinning && targetIndex !== undefined && targetIndex !== null) {
    // Calculate rotation to land on target
    const targetAngle = targetIndex * segmentAngle;
    // Add extra spins (e.g. 5 full rotations) + align center of segment to top (subtract 90 deg offset depending on drawing)
    // The pointer is usually at top (0 deg). The wheel draws segment 0 from -angle/2 to +angle/2.
    // So landing on segment targetIndex means we want targetAngle to be at 0 deg.
    // We rotate the wheel by -targetAngle + 360 * spins.
    const extraSpins = 360 * 5;
    const finalRotation = rotation + extraSpins + (360 - targetAngle) - (rotation % 360);
    
    controls.start({
      rotate: finalRotation,
      transition: { duration: 4, ease: [0.2, 0.8, 0.3, 1] }
    }).then(() => {
      setRotation(finalRotation);
      onSpinEnd(segments[targetIndex].label);
    });
  }

  return (
    <div className="relative w-72 h-72 mx-auto">
      {/* Pointer */}
      <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 z-20 drop-shadow-xl">
        <svg viewBox="0 0 100 100" className="w-full h-full fill-white stroke-gray-300 stroke-2">
          <polygon points="50,100 20,0 80,0" />
        </svg>
      </div>
      
      {/* Outer Border */}
      <div className="absolute inset-[-10px] rounded-full bg-gradient-to-br from-yellow-400 via-yellow-600 to-yellow-800 p-[10px] shadow-[0_0_30px_rgba(234,179,8,0.5)] z-0">
        <div className="w-full h-full rounded-full border-4 border-yellow-900/50 bg-black/50 backdrop-blur-sm" />
      </div>

      {/* Wheel */}
      <motion.div 
        className="w-full h-full rounded-full relative overflow-hidden z-10 border-2 border-white/20 shadow-inner"
        animate={controls}
        initial={{ rotate: 0 }}
      >
        {segments.map((segment, index) => {
          const rotate = index * segmentAngle;
          // conic-gradient trick or svg for segments. We'll use CSS conic gradient on the parent, or individual divs
          return (
            <div 
              key={segment.id}
              className="absolute top-0 right-1/2 w-1/2 h-full origin-right"
              style={{ 
                transform: `rotate(${rotate - segmentAngle/2}deg)`,
                overflow: 'hidden'
              }}
            >
              <div 
                className="w-[200%] h-[200%] origin-bottom-left absolute bottom-0 left-0 border-r border-white/20"
                style={{
                  backgroundColor: segment.color,
                  transform: `skewY(${segmentAngle - 90}deg)`
                }}
              />
            </div>
          );
        })}
        
        {/* Text/Labels */}
        {segments.map((segment, index) => {
          const rotate = index * segmentAngle;
          return (
            <div 
              key={`text-${segment.id}`}
              className="absolute inset-0 text-center font-bold text-white text-lg flex items-start justify-center pt-8 drop-shadow-md pointer-events-none"
              style={{ transform: `rotate(${rotate}deg)` }}
            >
              {segment.label}
            </div>
          );
        })}
        
        {/* Center dot */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-gradient-to-br from-yellow-300 to-yellow-600 border-4 border-yellow-800 shadow-xl z-20 flex items-center justify-center">
          <div className="w-4 h-4 rounded-full bg-yellow-200" />
        </div>
      </motion.div>
    </div>
  );
}
