import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, usersTable, withdrawalsTable } from "@workspace/db";
import {
  GetWithdrawalsQueryParams,
  RequestWithdrawalBody,
  GetWithdrawalsResponse,
  RequestWithdrawalResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const MIN_WITHDRAWAL = 100;

router.get("/withdrawals", async (req, res): Promise<void> => {
  const params = GetWithdrawalsQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const { telegramId } = params.data;

  const withdrawals = await db.select().from(withdrawalsTable)
    .where(eq(withdrawalsTable.telegramId, telegramId!))
    .orderBy(desc(withdrawalsTable.createdAt));

  const result = withdrawals.map((w) => ({
    ...w,
    amount: Number(w.amount),
    createdAt: w.createdAt.toISOString(),
    updatedAt: w.updatedAt.toISOString(),
  }));

  res.json(GetWithdrawalsResponse.parse(result));
});

router.post("/withdrawals", async (req, res): Promise<void> => {
  const parsed = RequestWithdrawalBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { telegramId, amount, method, accountNumber } = parsed.data;

  if (amount < MIN_WITHDRAWAL) {
    res.status(400).json({ error: `Minimum withdrawal is ${MIN_WITHDRAWAL} coins` });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.telegramId, telegramId));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  if (Number(user.withdrawableBalance) < amount) {
    res.status(400).json({ error: "Insufficient withdrawable balance" });
    return;
  }

  const newWithdrawable = Number(user.withdrawableBalance) - amount;
  await db.update(usersTable)
    .set({ withdrawableBalance: newWithdrawable.toString() })
    .where(eq(usersTable.telegramId, telegramId));

  const [withdrawal] = await db.insert(withdrawalsTable).values({
    telegramId,
    amount: amount.toString(),
    method,
    accountNumber,
    status: "pending",
  }).returning();

  res.json(RequestWithdrawalResponse.parse({
    ...withdrawal,
    amount: Number(withdrawal.amount),
    createdAt: withdrawal.createdAt.toISOString(),
    updatedAt: withdrawal.updatedAt.toISOString(),
  }));
});

export default router;
