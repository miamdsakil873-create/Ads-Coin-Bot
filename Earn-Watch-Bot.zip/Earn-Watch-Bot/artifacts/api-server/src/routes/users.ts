import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, referralsTable } from "@workspace/db";
import { RegisterUserBody, GetMeQueryParams, RegisterUserResponse, GetMeResponse } from "@workspace/api-zod";
import { nanoid } from "nanoid";

const router: IRouter = Router();

router.get("/users/me", async (req, res): Promise<void> => {
  const params = GetMeQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const telegramId = params.data.telegramId;
  if (!telegramId) {
    res.status(400).json({ error: "telegramId required" });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.telegramId, telegramId));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json(GetMeResponse.parse({
    ...user,
    balance: Number(user.balance),
    pendingBalance: Number(user.pendingBalance),
    withdrawableBalance: Number(user.withdrawableBalance),
    totalEarned: Number(user.totalEarned),
    createdAt: user.createdAt.toISOString(),
  }));
});

router.post("/users/register", async (req, res): Promise<void> => {
  const parsed = RegisterUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { telegramId, username, firstName, lastName, referralCode } = parsed.data;

  const [existing] = await db.select().from(usersTable).where(eq(usersTable.telegramId, telegramId));
  if (existing) {
    res.json(RegisterUserResponse.parse({
      ...existing,
      balance: Number(existing.balance),
      pendingBalance: Number(existing.pendingBalance),
      withdrawableBalance: Number(existing.withdrawableBalance),
      totalEarned: Number(existing.totalEarned),
      createdAt: existing.createdAt.toISOString(),
    }));
    return;
  }

  const newReferralCode = nanoid(8).toUpperCase();
  let referredBy: string | null = null;
  let referrer = null;

  if (referralCode) {
    const [refUser] = await db.select().from(usersTable).where(eq(usersTable.referralCode, referralCode));
    if (refUser) {
      referredBy = refUser.telegramId;
      referrer = refUser;
    }
  }

  const [newUser] = await db.insert(usersTable).values({
    telegramId,
    username: username || "user",
    firstName: firstName || "User",
    lastName: lastName || null,
    referralCode: newReferralCode,
    referredBy,
    balance: "0",
    pendingBalance: "0",
    withdrawableBalance: "0",
    totalEarned: "0",
    isAdmin: false,
    isBanned: false,
    streakDays: 0,
    spinAvailable: false,
    scratchAvailable: false,
  }).returning();

  if (referrer) {
    const L1_BONUS = 50;
    const L2_BONUS = 25;
    const L3_BONUS = 10;

    await db.insert(referralsTable).values({
      referrerId: referrer.telegramId,
      referredId: telegramId,
      level: 1,
      bonusCoins: L1_BONUS.toString(),
    });
    await db.update(usersTable)
      .set({ balance: (Number(referrer.balance) + L1_BONUS).toString() })
      .where(eq(usersTable.telegramId, referrer.telegramId));

    if (referrer.referredBy) {
      const [grandRef] = await db.select().from(usersTable).where(eq(usersTable.telegramId, referrer.referredBy));
      if (grandRef) {
        await db.insert(referralsTable).values({
          referrerId: grandRef.telegramId,
          referredId: telegramId,
          level: 2,
          bonusCoins: L2_BONUS.toString(),
        });
        await db.update(usersTable)
          .set({ balance: (Number(grandRef.balance) + L2_BONUS).toString() })
          .where(eq(usersTable.telegramId, grandRef.telegramId));

        if (grandRef.referredBy) {
          const [greatRef] = await db.select().from(usersTable).where(eq(usersTable.telegramId, grandRef.referredBy));
          if (greatRef) {
            await db.insert(referralsTable).values({
              referrerId: greatRef.telegramId,
              referredId: telegramId,
              level: 3,
              bonusCoins: L3_BONUS.toString(),
            });
            await db.update(usersTable)
              .set({ balance: (Number(greatRef.balance) + L3_BONUS).toString() })
              .where(eq(usersTable.telegramId, greatRef.telegramId));
          }
        }
      }
    }
  }

  res.json(RegisterUserResponse.parse({
    ...newUser,
    balance: Number(newUser.balance),
    pendingBalance: Number(newUser.pendingBalance),
    withdrawableBalance: Number(newUser.withdrawableBalance),
    totalEarned: Number(newUser.totalEarned),
    createdAt: newUser.createdAt.toISOString(),
  }));
});

export default router;
