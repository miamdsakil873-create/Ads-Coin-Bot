import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import tasksRouter from "./tasks";
import rewardsRouter from "./rewards";
import referralsRouter from "./referrals";
import withdrawalsRouter from "./withdrawals";
import dashboardRouter from "./dashboard";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(usersRouter);
router.use(tasksRouter);
router.use(rewardsRouter);
router.use(referralsRouter);
router.use(withdrawalsRouter);
router.use(dashboardRouter);
router.use(adminRouter);

export default router;
