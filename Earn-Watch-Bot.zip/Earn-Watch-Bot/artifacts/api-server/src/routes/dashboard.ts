import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, usersTable, taskDefinitionsTable, userTaskCompletionsTable, announcementsTable } from "@workspace/db";
import { GetDashboardSummaryQueryParams, GetDashboardSummaryResponse } from "@workspace/api-zod";
import { desc } from "drizzle-orm";

const router: IRouter = Router();

function getTodayDate(): string {
  return new Date().toISOString().split("T")[0];
}

router.get("/dashboard/summary", async (req, res): Promise<void> => {
  const params = GetDashboardSummaryQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const { telegramId } = params.data;
  const today = getTodayDate();

  const [user] = await db.select().from(usersTable).where(eq(usersTable.telegramId, telegramId));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const allTasks = await db.select().from(taskDefinitionsTable).where(eq(taskDefinitionsTable.isActive, true));
  const completedToday = await db.select().from(userTaskCompletionsTable).where(
    and(
      eq(userTaskCompletionsTable.telegramId, telegramId),
      eq(userTaskCompletionsTable.completedDate, today)
    )
  );

  const totalTasksToday = allTasks.length;
  const tasksCompletedToday = completedToday.length;
  const dailyProgress = totalTasksToday > 0 ? (tasksCompletedToday / totalTasksToday) * 100 : 0;

  const announcements = await db.select().from(announcementsTable).orderBy(desc(announcementsTable.createdAt)).limit(3);

  res.json(GetDashboardSummaryResponse.parse({
    balance: Number(user.balance),
    pendingBalance: Number(user.pendingBalance),
    withdrawableBalance: Number(user.withdrawableBalance),
    totalEarned: Number(user.totalEarned),
    tasksCompletedToday,
    totalTasksToday,
    dailyProgress,
    streakDays: user.streakDays,
    referralCount: 0,
    spinAvailable: user.spinAvailable,
    scratchAvailable: user.scratchAvailable,
    announcements: announcements.map((a) => ({
      ...a,
      createdAt: a.createdAt.toISOString(),
    })),
  }));
});

export default router;
