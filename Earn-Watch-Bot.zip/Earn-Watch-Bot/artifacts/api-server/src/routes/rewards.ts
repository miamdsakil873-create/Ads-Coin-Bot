import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, rewardLogsTable } from "@workspace/db";
import { SpinWheelBody, ScratchCardBody, SpinWheelResponse, ScratchCardResponse } from "@workspace/api-zod";

const router: IRouter = Router();

function getTodayDate(): string {
  return new Date().toISOString().split("T")[0];
}

const SPIN_PRIZES = [
  { label: "10 Coins", coins: 10 },
  { label: "25 Coins", coins: 25 },
  { label: "50 Coins", coins: 50 },
  { label: "5 Coins", coins: 5 },
  { label: "100 Coins", coins: 100 },
  { label: "15 Coins", coins: 15 },
  { label: "30 Coins", coins: 30 },
  { label: "75 Coins", coins: 75 },
];

const SCRATCH_PRIZES = [
  { label: "5 Coins", coins: 5 },
  { label: "10 Coins", coins: 10 },
  { label: "20 Coins", coins: 20 },
  { label: "50 Coins", coins: 50 },
  { label: "No Prize", coins: 0 },
  { label: "No Prize", coins: 0 },
];

router.post("/rewards/spin", async (req, res): Promise<void> => {
  const parsed = SpinWheelBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { telegramId } = parsed.data;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.telegramId, telegramId));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  if (!user.spinAvailable) {
    res.status(400).json({ error: "Spin not available. Complete all ad tasks first." });
    return;
  }

  const slotIndex = Math.floor(Math.random() * SPIN_PRIZES.length);
  const prize = SPIN_PRIZES[slotIndex];
  const newBalance = Number(user.balance) + prize.coins;
  const newTotalEarned = Number(user.totalEarned) + prize.coins;

  await db.update(usersTable)
    .set({
      balance: newBalance.toString(),
      totalEarned: newTotalEarned.toString(),
      spinAvailable: false,
    })
    .where(eq(usersTable.telegramId, telegramId));

  await db.insert(rewardLogsTable).values({
    telegramId,
    rewardType: "spin",
    prize: prize.label,
    coinsEarned: prize.coins,
    rewardDate: getTodayDate(),
  });

  res.json(SpinWheelResponse.parse({
    prize: prize.label,
    coinsEarned: prize.coins,
    newBalance,
    slotIndex,
  }));
});

router.post("/rewards/scratch", async (req, res): Promise<void> => {
  const parsed = ScratchCardBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { telegramId } = parsed.data;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.telegramId, telegramId));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  if (!user.scratchAvailable) {
    res.status(400).json({ error: "Scratch card not available. Complete all ad tasks first." });
    return;
  }

  const idx = Math.floor(Math.random() * SCRATCH_PRIZES.length);
  const prize = SCRATCH_PRIZES[idx];
  const newBalance = Number(user.balance) + prize.coins;
  const newTotalEarned = Number(user.totalEarned) + prize.coins;

  await db.update(usersTable)
    .set({
      balance: newBalance.toString(),
      totalEarned: newTotalEarned.toString(),
      scratchAvailable: false,
    })
    .where(eq(usersTable.telegramId, telegramId));

  await db.insert(rewardLogsTable).values({
    telegramId,
    rewardType: "scratch",
    prize: prize.label,
    coinsEarned: prize.coins,
    rewardDate: getTodayDate(),
  });

  res.json(ScratchCardResponse.parse({
    prize: prize.label,
    coinsEarned: prize.coins,
    newBalance,
  }));
});

export default router;
