import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, usersTable, taskDefinitionsTable, userTaskCompletionsTable } from "@workspace/db";
import {
  GetTasksQueryParams,
  CompleteTaskBody,
  GetTasksResponse,
  CompleteTaskResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function getTodayDate(): string {
  return new Date().toISOString().split("T")[0];
}

router.get("/tasks", async (req, res): Promise<void> => {
  const params = GetTasksQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const { telegramId } = params.data;
  const today = getTodayDate();

  const allTasks = await db.select().from(taskDefinitionsTable).where(eq(taskDefinitionsTable.isActive, true));

  const completedToday = await db.select().from(userTaskCompletionsTable).where(
    and(
      eq(userTaskCompletionsTable.telegramId, telegramId!),
      eq(userTaskCompletionsTable.completedDate, today)
    )
  );

  const completedIds = new Set(completedToday.map((c) => c.taskDefinitionId));

  const result = allTasks.map((task) => ({
    id: task.id,
    taskType: task.taskType,
    title: task.title,
    description: task.description,
    buttonText: task.buttonText,
    rewardCoins: task.rewardCoins,
    isCompleted: completedIds.has(task.id),
    completedAt: completedToday.find((c) => c.taskDefinitionId === task.id)?.completedAt?.toISOString() ?? null,
    adUrl: task.adUrl ?? null,
    linkUrl: task.linkUrl ?? null,
    taskOrder: task.taskOrder,
    timerSeconds: task.timerSeconds,
  }));

  result.sort((a, b) => a.taskOrder - b.taskOrder);

  res.json(GetTasksResponse.parse(result));
});

router.post("/tasks/complete", async (req, res): Promise<void> => {
  const parsed = CompleteTaskBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { telegramId, taskId } = parsed.data;
  const today = getTodayDate();

  const [user] = await db.select().from(usersTable).where(eq(usersTable.telegramId, telegramId));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const [task] = await db.select().from(taskDefinitionsTable).where(eq(taskDefinitionsTable.id, taskId));
  if (!task) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  const [already] = await db.select().from(userTaskCompletionsTable).where(
    and(
      eq(userTaskCompletionsTable.telegramId, telegramId),
      eq(userTaskCompletionsTable.taskDefinitionId, taskId),
      eq(userTaskCompletionsTable.completedDate, today)
    )
  );

  if (already) {
    res.status(400).json({ error: "Task already completed today" });
    return;
  }

  await db.insert(userTaskCompletionsTable).values({
    telegramId,
    taskDefinitionId: taskId,
    completedDate: today,
  });

  const newBalance = Number(user.balance) + task.rewardCoins;
  const newTotalEarned = Number(user.totalEarned) + task.rewardCoins;

  const allTasks = await db.select().from(taskDefinitionsTable).where(eq(taskDefinitionsTable.isActive, true));
  const adTasks = allTasks.filter((t) => t.taskType === "watch_ad");
  const completedToday = await db.select().from(userTaskCompletionsTable).where(
    and(
      eq(userTaskCompletionsTable.telegramId, telegramId),
      eq(userTaskCompletionsTable.completedDate, today)
    )
  );
  const completedAdCount = completedToday.filter((c) => {
    const tDef = allTasks.find((t) => t.id === c.taskDefinitionId);
    return tDef?.taskType === "watch_ad";
  }).length;

  const allAdsCompleted = completedAdCount >= adTasks.length;

  await db.update(usersTable)
    .set({
      balance: newBalance.toString(),
      totalEarned: newTotalEarned.toString(),
      spinAvailable: allAdsCompleted ? true : user.spinAvailable,
      scratchAvailable: allAdsCompleted ? true : user.scratchAvailable,
    })
    .where(eq(usersTable.telegramId, telegramId));

  res.json(CompleteTaskResponse.parse({
    success: true,
    coinsEarned: task.rewardCoins,
    newBalance,
    message: `You earned ${task.rewardCoins} coins!`,
  }));
});

export default router;
