import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, referralsTable } from "@workspace/db";
import { GetReferralsQueryParams, GetReferralsResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/referrals", async (req, res): Promise<void> => {
  const params = GetReferralsQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const { telegramId } = params.data;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.telegramId, telegramId!));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const myReferrals = await db.select().from(referralsTable).where(eq(referralsTable.referrerId, telegramId!));

  const level1 = myReferrals.filter((r) => r.level === 1);
  const level2 = myReferrals.filter((r) => r.level === 2);
  const level3 = myReferrals.filter((r) => r.level === 3);

  const totalEarned = myReferrals.reduce((sum, r) => sum + Number(r.bonusCoins), 0);

  const referralListWithDetails = await Promise.all(myReferrals.slice(0, 20).map(async (r) => {
    const [referredUser] = await db.select().from(usersTable).where(eq(usersTable.telegramId, r.referredId));
    return {
      username: referredUser?.username || "unknown",
      level: r.level,
      joinedAt: r.createdAt.toISOString(),
      earnedCoins: Number(r.bonusCoins),
    };
  }));

  const BOT_USERNAME = "YourBotUsername";
  const referralLink = `https://t.me/${BOT_USERNAME}?start=${user.referralCode}`;

  res.json(GetReferralsResponse.parse({
    referralCode: user.referralCode,
    referralLink,
    totalReferrals: myReferrals.length,
    level1Referrals: level1.length,
    level2Referrals: level2.length,
    level3Referrals: level3.length,
    totalEarnedFromReferrals: totalEarned,
    referralList: referralListWithDetails,
  }));
});

export default router;
