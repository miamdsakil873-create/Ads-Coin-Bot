import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { eq, count, desc, ilike, or } from "drizzle-orm";
import { db, usersTable, withdrawalsTable, announcementsTable, userTaskCompletionsTable, taskDefinitionsTable, platformSettingsTable } from "@workspace/db";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import {
  AdminGetUsersQueryParams,
  AdminUpdateUserParams,
  AdminUpdateUserBody,
  AdminUpdateWithdrawalStatusParams,
  AdminUpdateWithdrawalStatusBody,
  AdminPostAnnouncementBody,
  AdminDeleteAnnouncementParams,
  AdminDeleteTaskParams,
  AdminCreateTaskBody,
  AdminUpdateTaskBody,
  AdminUpdateTaskParams,
  AdminGetWithdrawalsQueryParams,
  AdminBroadcastBody,
  AdminUpdateSettingsBody,
  AdminAuthLoginBody,
  AdminGetUsersResponse,
  AdminGetWithdrawalsResponse,
  AdminUpdateWithdrawalStatusResponse,
  AdminPostAnnouncementResponse,
  AdminGetAnnouncementsResponse,
  AdminDeleteAnnouncementResponse,
  AdminGetStatsResponse,
  AdminGetTasksResponse,
  AdminCreateTaskResponse,
  AdminUpdateTaskResponse,
  AdminDeleteTaskResponse,
  AdminUpdateUserResponse,
  AdminGetSettingsResponse,
  AdminUpdateSettingsResponse,
  AdminBroadcastResponse,
  AdminAuthLoginResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const JWT_SECRET = process.env["SESSION_SECRET"] ?? "fallback-secret-do-not-use-in-prod";

function formatUser(u: typeof usersTable.$inferSelect) {
  return {
    ...u,
    balance: Number(u.balance),
    pendingBalance: Number(u.pendingBalance),
    withdrawableBalance: Number(u.withdrawableBalance),
    totalEarned: Number(u.totalEarned),
    createdAt: u.createdAt.toISOString(),
  };
}

function formatWithdrawal(w: typeof withdrawalsTable.$inferSelect) {
  return {
    ...w,
    amount: Number(w.amount),
    createdAt: w.createdAt.toISOString(),
    updatedAt: w.updatedAt.toISOString(),
  };
}

function formatTask(t: typeof taskDefinitionsTable.$inferSelect) {
  return {
    ...t,
    createdAt: t.createdAt.toISOString(),
  };
}

function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  const token = req.headers["x-admin-token"] as string | undefined;
  if (!token) {
    res.status(401).json({ error: "Admin token required" });
    return;
  }
  try {
    jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Invalid or expired admin token" });
  }
}

router.post("/admin/auth/login", async (req, res): Promise<void> => {
  const parsed = AdminAuthLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { username, password } = parsed.data;

  const [adminUser] = await db.select().from(usersTable).where(eq(usersTable.isAdmin, true)).limit(1);

  const defaultAdminUsername = "admin";
  const defaultAdminPassword = "admin123";

  let isValid = false;
  if (adminUser) {
    if (adminUser.passwordHash) {
      isValid = username === (adminUser.username || defaultAdminUsername) && await bcrypt.compare(password, adminUser.passwordHash);
    } else {
      isValid = username === defaultAdminUsername && password === defaultAdminPassword;
    }
  } else {
    isValid = username === defaultAdminUsername && password === defaultAdminPassword;
  }

  if (!isValid) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const token = jwt.sign({ username, isAdmin: true }, JWT_SECRET, { expiresIn: "7d" });

  res.json(AdminAuthLoginResponse.parse({ token, username }));
});

router.get("/admin/users", requireAdmin, async (req, res): Promise<void> => {
  const params = AdminGetUsersQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const page = params.data.page ?? 1;
  const limit = params.data.limit ?? 20;
  const offset = (page - 1) * limit;
  const search = params.data.search;

  let query = db.select().from(usersTable).orderBy(desc(usersTable.createdAt)).limit(limit).offset(offset);

  const users = search
    ? await db.select().from(usersTable)
        .where(or(
          ilike(usersTable.username, `%${search}%`),
          ilike(usersTable.telegramId, `%${search}%`),
          ilike(usersTable.firstName, `%${search}%`),
        ))
        .orderBy(desc(usersTable.createdAt)).limit(limit).offset(offset)
    : await query;

  const [{ value: total }] = await db.select({ value: count() }).from(usersTable);

  res.json(AdminGetUsersResponse.parse({
    users: users.map(formatUser),
    total,
    page,
    limit,
  }));
});

router.patch("/admin/users/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const idParam = AdminUpdateUserParams.safeParse({ id: parseInt(rawId, 10) });
  if (!idParam.success) {
    res.status(400).json({ error: idParam.error.message });
    return;
  }

  const parsed = AdminUpdateUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, idParam.data.id));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const updateData: Partial<typeof usersTable.$inferInsert> = {};
  if (parsed.data.isBanned !== undefined) updateData.isBanned = parsed.data.isBanned;
  if (parsed.data.balance !== undefined) updateData.balance = parsed.data.balance.toString();
  if (parsed.data.withdrawableBalance !== undefined) updateData.withdrawableBalance = parsed.data.withdrawableBalance.toString();

  const [updated] = await db.update(usersTable).set(updateData).where(eq(usersTable.id, idParam.data.id)).returning();

  res.json(AdminUpdateUserResponse.parse(formatUser(updated)));
});

router.get("/admin/tasks", requireAdmin, async (req, res): Promise<void> => {
  const tasks = await db.select().from(taskDefinitionsTable).orderBy(taskDefinitionsTable.taskOrder);
  res.json(AdminGetTasksResponse.parse(tasks.map(formatTask)));
});

router.post("/admin/tasks", requireAdmin, async (req, res): Promise<void> => {
  const parsed = AdminCreateTaskBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [task] = await db.insert(taskDefinitionsTable).values({
    taskType: parsed.data.taskType,
    title: parsed.data.title,
    description: parsed.data.description,
    buttonText: parsed.data.buttonText,
    rewardCoins: parsed.data.rewardCoins,
    adUrl: parsed.data.adUrl ?? null,
    linkUrl: parsed.data.linkUrl ?? null,
    taskOrder: parsed.data.taskOrder,
    timerSeconds: parsed.data.timerSeconds,
    isActive: parsed.data.isActive,
  }).returning();

  res.json(AdminCreateTaskResponse.parse(formatTask(task)));
});

router.put("/admin/tasks/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const idParam = AdminUpdateTaskParams.safeParse({ id: parseInt(rawId, 10) });
  if (!idParam.success) {
    res.status(400).json({ error: idParam.error.message });
    return;
  }

  const parsed = AdminUpdateTaskBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [existing] = await db.select().from(taskDefinitionsTable).where(eq(taskDefinitionsTable.id, idParam.data.id));
  if (!existing) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  const [updated] = await db.update(taskDefinitionsTable).set({
    taskType: parsed.data.taskType,
    title: parsed.data.title,
    description: parsed.data.description,
    buttonText: parsed.data.buttonText,
    rewardCoins: parsed.data.rewardCoins,
    adUrl: parsed.data.adUrl ?? null,
    linkUrl: parsed.data.linkUrl ?? null,
    taskOrder: parsed.data.taskOrder,
    timerSeconds: parsed.data.timerSeconds,
    isActive: parsed.data.isActive,
  }).where(eq(taskDefinitionsTable.id, idParam.data.id)).returning();

  res.json(AdminUpdateTaskResponse.parse(formatTask(updated)));
});

router.delete("/admin/tasks/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const idParam = AdminDeleteTaskParams.safeParse({ id: parseInt(rawId, 10) });
  if (!idParam.success) {
    res.status(400).json({ error: idParam.error.message });
    return;
  }

  await db.delete(taskDefinitionsTable).where(eq(taskDefinitionsTable.id, idParam.data.id));
  res.json(AdminDeleteTaskResponse.parse({ success: true }));
});

router.get("/admin/withdrawals", requireAdmin, async (req, res): Promise<void> => {
  const params = AdminGetWithdrawalsQueryParams.safeParse(req.query);
  const statusFilter = params.success ? params.data.status : undefined;

  let withdrawals;
  if (statusFilter) {
    withdrawals = await db.select().from(withdrawalsTable).where(eq(withdrawalsTable.status, statusFilter)).orderBy(desc(withdrawalsTable.createdAt));
  } else {
    withdrawals = await db.select().from(withdrawalsTable).orderBy(desc(withdrawalsTable.createdAt));
  }

  res.json(AdminGetWithdrawalsResponse.parse(withdrawals.map(formatWithdrawal)));
});

router.patch("/admin/withdrawals/:id/status", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const idParam = AdminUpdateWithdrawalStatusParams.safeParse({ id: parseInt(rawId, 10) });
  if (!idParam.success) {
    res.status(400).json({ error: idParam.error.message });
    return;
  }

  const parsed = AdminUpdateWithdrawalStatusBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [withdrawal] = await db.select().from(withdrawalsTable).where(eq(withdrawalsTable.id, idParam.data.id));
  if (!withdrawal) {
    res.status(404).json({ error: "Withdrawal not found" });
    return;
  }

  const [updated] = await db.update(withdrawalsTable)
    .set({ status: parsed.data.status, note: parsed.data.note ?? null })
    .where(eq(withdrawalsTable.id, idParam.data.id))
    .returning();

  res.json(AdminUpdateWithdrawalStatusResponse.parse(formatWithdrawal(updated)));
});

router.post("/admin/announcements", requireAdmin, async (req, res): Promise<void> => {
  const parsed = AdminPostAnnouncementBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [announcement] = await db.insert(announcementsTable).values({
    title: parsed.data.title,
    message: parsed.data.message,
    type: parsed.data.type,
  }).returning();

  res.json(AdminPostAnnouncementResponse.parse({
    ...announcement,
    createdAt: announcement.createdAt.toISOString(),
  }));
});

router.get("/admin/announcements", requireAdmin, async (req, res): Promise<void> => {
  const announcements = await db.select().from(announcementsTable).orderBy(desc(announcementsTable.createdAt));

  res.json(AdminGetAnnouncementsResponse.parse(announcements.map((a) => ({
    ...a,
    createdAt: a.createdAt.toISOString(),
  }))));
});

router.delete("/admin/announcements/:id", requireAdmin, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const idParam = AdminDeleteAnnouncementParams.safeParse({ id: parseInt(rawId, 10) });
  if (!idParam.success) {
    res.status(400).json({ error: idParam.error.message });
    return;
  }

  await db.delete(announcementsTable).where(eq(announcementsTable.id, idParam.data.id));
  res.json(AdminDeleteAnnouncementResponse.parse({ success: true }));
});

router.get("/admin/stats", requireAdmin, async (req, res): Promise<void> => {
  const [{ value: totalUsers }] = await db.select({ value: count() }).from(usersTable);
  const [{ value: totalTasksCompleted }] = await db.select({ value: count() }).from(userTaskCompletionsTable);
  const [{ value: bannedUsers }] = await db.select({ value: count() }).from(usersTable).where(eq(usersTable.isBanned, true));

  const allUsers = await db.select({ totalEarned: usersTable.totalEarned }).from(usersTable);
  const totalCoinsDistributed = allUsers.reduce((s, u) => s + Number(u.totalEarned), 0);

  const [{ value: pendingWithdrawals }] = await db.select({ value: count() }).from(withdrawalsTable).where(eq(withdrawalsTable.status, "pending"));

  const approvedWithdrawals = await db.select({ amount: withdrawalsTable.amount }).from(withdrawalsTable).where(eq(withdrawalsTable.status, "approved"));
  const totalWithdrawn = approvedWithdrawals.reduce((s, w) => s + Number(w.amount), 0);

  const today = new Date().toISOString().split("T")[0];
  const todayCompletions = await db.select({ telegramId: userTaskCompletionsTable.telegramId }).from(userTaskCompletionsTable).where(eq(userTaskCompletionsTable.completedDate, today));
  const activeUsersToday = new Set(todayCompletions.map((c) => c.telegramId)).size;

  res.json(AdminGetStatsResponse.parse({
    totalUsers,
    activeUsersToday,
    totalTasksCompleted,
    totalCoinsDistributed,
    pendingWithdrawals,
    totalWithdrawn,
    bannedUsers,
    newUsersToday: 0,
  }));
});

router.get("/admin/settings", requireAdmin, async (req, res): Promise<void> => {
  const settings = await db.select().from(platformSettingsTable);
  const settingsMap: Record<string, string> = {};
  for (const s of settings) {
    settingsMap[s.key] = s.value;
  }

  res.json(AdminGetSettingsResponse.parse({
    siteName: settingsMap["siteName"] ?? "Watch Ads & Earn",
    dailyAdLimit: parseInt(settingsMap["dailyAdLimit"] ?? "10"),
    rewardPerAd: parseFloat(settingsMap["rewardPerAd"] ?? "5"),
    minWithdrawal: parseFloat(settingsMap["minWithdrawal"] ?? "500"),
    referralLevel1Bonus: parseFloat(settingsMap["referralLevel1Bonus"] ?? "50"),
    referralLevel2Bonus: parseFloat(settingsMap["referralLevel2Bonus"] ?? "25"),
    referralLevel3Bonus: parseFloat(settingsMap["referralLevel3Bonus"] ?? "10"),
    currency: settingsMap["currency"] ?? "BDT",
    botUsername: settingsMap["botUsername"] ?? "EarnBot",
  }));
});

router.put("/admin/settings", requireAdmin, async (req, res): Promise<void> => {
  const parsed = AdminUpdateSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const entries = Object.entries(parsed.data) as [string, string | number][];
  for (const [key, value] of entries) {
    await db.insert(platformSettingsTable)
      .values({ key, value: String(value) })
      .onConflictDoUpdate({ target: platformSettingsTable.key, set: { value: String(value) } });
  }

  const settings = await db.select().from(platformSettingsTable);
  const settingsMap: Record<string, string> = {};
  for (const s of settings) {
    settingsMap[s.key] = s.value;
  }

  res.json(AdminUpdateSettingsResponse.parse({
    siteName: settingsMap["siteName"] ?? "Watch Ads & Earn",
    dailyAdLimit: parseInt(settingsMap["dailyAdLimit"] ?? "10"),
    rewardPerAd: parseFloat(settingsMap["rewardPerAd"] ?? "5"),
    minWithdrawal: parseFloat(settingsMap["minWithdrawal"] ?? "500"),
    referralLevel1Bonus: parseFloat(settingsMap["referralLevel1Bonus"] ?? "50"),
    referralLevel2Bonus: parseFloat(settingsMap["referralLevel2Bonus"] ?? "25"),
    referralLevel3Bonus: parseFloat(settingsMap["referralLevel3Bonus"] ?? "10"),
    currency: settingsMap["currency"] ?? "BDT",
    botUsername: settingsMap["botUsername"] ?? "EarnBot",
  }));
});

router.post("/admin/broadcast", requireAdmin, async (req, res): Promise<void> => {
  const parsed = AdminBroadcastBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { title, message, targetTelegramId } = parsed.data;

  let recipientCount = 0;
  if (targetTelegramId) {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.telegramId, targetTelegramId));
    recipientCount = user ? 1 : 0;
  } else {
    const [{ value }] = await db.select({ value: count() }).from(usersTable).where(eq(usersTable.isBanned, false));
    recipientCount = value;
  }

  await db.insert(announcementsTable).values({ title, message, type: "info" });

  res.json(AdminBroadcastResponse.parse({
    success: true,
    recipientCount,
    message: `Broadcast sent to ${recipientCount} user(s)`,
  }));
});

export default router;
