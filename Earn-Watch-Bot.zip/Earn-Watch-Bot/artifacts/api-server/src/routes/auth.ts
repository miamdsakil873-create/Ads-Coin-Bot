import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, referralsTable } from "@workspace/db";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { nanoid } from "nanoid";
import { AuthRegisterBody, AuthLoginBody, AuthRegisterResponse, AuthLoginResponse } from "@workspace/api-zod";

const router: IRouter = Router();
const JWT_SECRET = process.env["SESSION_SECRET"] ?? "fallback-secret-do-not-use-in-prod";

function formatUser(u: typeof usersTable.$inferSelect) {
  return {
    ...u,
    balance: Number(u.balance),
    pendingBalance: Number(u.pendingBalance),
    withdrawableBalance: Number(u.withdrawableBalance),
    totalEarned: Number(u.totalEarned),
    createdAt: u.createdAt.toISOString(),
  };
}

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = AuthRegisterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { email, password, username, telegramId, referralCode } = parsed.data;

  const [existing] = await db.select().from(usersTable).where(eq(usersTable.telegramId, telegramId ?? email));
  if (existing) {
    res.status(400).json({ error: "User already exists" });
    return;
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const newReferralCode = nanoid(8).toUpperCase();
  let referredBy: string | null = null;

  if (referralCode) {
    const [refUser] = await db.select().from(usersTable).where(eq(usersTable.referralCode, referralCode));
    if (refUser) {
      referredBy = refUser.telegramId;
    }
  }

  const [newUser] = await db.insert(usersTable).values({
    telegramId: telegramId ?? `email:${email}`,
    username,
    firstName: username,
    email,
    passwordHash,
    referralCode: newReferralCode,
    referredBy,
    balance: "0",
    pendingBalance: "0",
    withdrawableBalance: "0",
    totalEarned: "0",
    isAdmin: false,
    isBanned: false,
    streakDays: 0,
    spinAvailable: false,
    scratchAvailable: false,
  }).returning();

  const token = jwt.sign({ userId: newUser.id, telegramId: newUser.telegramId }, JWT_SECRET, { expiresIn: "30d" });

  res.json(AuthRegisterResponse.parse({ token, user: formatUser(newUser) }));
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = AuthLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { email, password } = parsed.data;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.telegramId, `email:${email}`));
  if (!user) {
    const [byEmail] = await db.select().from(usersTable).where(eq(usersTable.email as any, email));
    if (!byEmail || !byEmail.passwordHash) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }
    const valid = await bcrypt.compare(password, byEmail.passwordHash);
    if (!valid) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }
    const token = jwt.sign({ userId: byEmail.id, telegramId: byEmail.telegramId }, JWT_SECRET, { expiresIn: "30d" });
    res.json(AuthLoginResponse.parse({ token, user: formatUser(byEmail) }));
    return;
  }

  if (!user.passwordHash) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }
  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const token = jwt.sign({ userId: user.id, telegramId: user.telegramId }, JWT_SECRET, { expiresIn: "30d" });
  res.json(AuthLoginResponse.parse({ token, user: formatUser(user) }));
});

export default router;
