# Workspace

## Overview

pnpm workspace monorepo using TypeScript. "Watch Ads & Earn Money" Telegram Web App platform.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite + TailwindCSS + shadcn/ui + framer-motion

## Artifacts

- **earn-platform** — Main React web app (Watch Ads & Earn platform). Preview at `/`.
- **api-server** — Express API server. Serves at `/api`.

## Key Features

- Dashboard with coin balance, daily tasks progress, streak tracking
- 10 daily ad-watching tasks (Monitag integration via webview links)
- Visit & Sign Up tasks, Daily Login Bonus
- Spin Wheel reward (unlocked after completing all ad tasks)
- Scratch Card reward (unlocked after completing all ad tasks)
- 3-level referral system with bonus coins
- Withdrawal system (bKash, Nagad, Crypto) — minimum 100 coins
- Admin panel: user management, withdrawal approval/rejection, announcements
- Demo user: telegramId="123456789" (admin)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

## Database Schema

- `users` — user accounts (telegramId, balance, referralCode, spinAvailable, scratchAvailable)
- `task_definitions` — task templates (watch_ad, visit_link, daily_login, signup_bonus)
- `user_task_completions` — daily task completion records
- `withdrawals` — withdrawal requests with status
- `referrals` — multi-level referral tracking
- `announcements` — admin announcements
- `reward_logs` — spin/scratch reward history

## Notes

- Frontend uses mock telegramId "123456789" (admin user) for demo
- Tasks reset every 24 hours (tracked by YYYY-MM-DD date string)
- Multi-level referrals: L1=50 coins, L2=25 coins, L3=10 coins
- Spin/Scratch unlocked when ALL ad tasks are completed for the day
